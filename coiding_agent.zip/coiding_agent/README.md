# Coding Agent

一个从零实现的现代 Python CLI Coding Agent 项目，面向本地代码仓库的代码理解、工具调用、安全编辑、测试验证、代码审查和执行过程追踪。

项目重点不是简单调用大模型，而是围绕真实 Agent 工程实践搭建完整能力：模型接入、结构化动作协议、工具系统、上下文工程、多阶段 workflow、分层 guardrails、代码检索、命令沙箱、session memory、trace-span 可观测性和本地 eval harness。

## 项目亮点

- 支持 OpenAI-compatible 模型接入，兼容 Responses API 和 Chat Completions API。
- 支持自定义 JSON 协议、原生 Tool Calling 和结构化动作协议。
- 实现 Tool Registry，统一管理工具描述、参数 Schema、参数校验和工具执行。
- 内置只读工具、代码检索工具、安全编辑工具和白名单命令工具。
- 支持 workspace-safe 文件访问，拒绝路径逃逸和敏感路径访问。
- 支持 `--review` 只读代码审查模式。
- 支持 `--trace-file` 输出 JSONL 审计日志。
- 支持 `--trace-format spans` 输出 span 风格可观测性事件。
- 支持 SQLite session history，用于保存和恢复任务历史。
- 支持 `--command-mode temp` 在临时目录副本中执行测试命令，避免污染原工作区。
- V2 模块化能力集中在 `src/coding_agent/v2/`，便于继续扩展。

## 技术栈

- 语言与工程：Python、setuptools、Pytest
- 模型接入：OpenAI API、Responses API、Chat Completions API、OpenAI-compatible Provider
- Agent 能力：Tool Calling、Structured Outputs 风格动作协议、Agent Workflow、Guardrails
- 代码理解：AST 解析、代码索引、关键词检索、Code Chunk Retrieval
- 存储与追踪：SQLite、JSONL、Trace Span
- 安全执行：Workspace Path Validation、Sensitive Path Blocking、Command Allowlist、Temp Sandbox
- 工具协议：本地 Tool Registry、MCP-compatible Tool Adapter

## 目录结构

```text
src/coding_agent/
├── agent.py                 # Agent 主循环
├── llm.py                   # OpenAI-compatible 模型客户端
├── schema.py                # 动作解析协议
├── memory.py                # 单次任务 memory
├── planner.py               # 轻量 planner
├── executor.py              # 工具执行器
├── tracing.py               # 控制台追踪
├── audit.py                 # JSONL 审计日志与 span trace
├── indexer.py               # 工作区摘要与代码索引
├── code_intelligence.py     # 项目级代码理解
├── runtime/
│   ├── retrieval.py         # 本地代码 chunk 检索
│   ├── sandbox.py           # 临时目录命令执行
│   └── session_store.py     # SQLite session history
├── tools/
│   ├── readonly.py          # list_files / read_file / search_text
│   ├── indexing.py          # summarize_workspace
│   ├── retrieval.py         # search_code_chunks
│   ├── editing.py           # write_file / apply_patch
│   ├── commands.py          # run_command
│   └── schema.py            # 工具参数 Schema
└── v2/
    ├── actions.py           # 结构化动作协议
    ├── context.py           # Context Engine
    ├── guardrails.py        # 分层护栏
    ├── workflow.py          # 多阶段 workflow
    ├── tool_adapters.py     # direct / MCP-compatible 工具适配
    └── spans.py             # trace-span 事件模型
```

## 安装

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pip install -e ".[dev]"
```

当前项目声明支持：

```text
Python >=3.11,<3.14
```

## 配置

复制 `.env.example`：

```powershell
Copy-Item .env.example .env
```

示例配置：

```env
OPENAI_API_KEY=your-api-key
OPENAI_MODEL=gpt-5.4-mini
OPENAI_BASE_URL=
OPENAI_API_MODE=responses
TOOL_CALLING_MODE=json
```

配置说明：

- `OPENAI_API_KEY`：必填，模型服务 API Key。
- `OPENAI_MODEL`：可选，模型名称。
- `OPENAI_BASE_URL`：可选，第三方 OpenAI-compatible 服务地址。
- `OPENAI_API_MODE`：可选，支持 `responses` 或 `chat_completions`。
- `TOOL_CALLING_MODE`：可选，支持 `json`、`native`、`structured`。

DeepSeek 等第三方兼容服务可使用：

```env
OPENAI_API_KEY=your-provider-key
OPENAI_MODEL=your-model-name
OPENAI_BASE_URL=https://your-provider.example/v1
OPENAI_API_MODE=chat_completions
TOOL_CALLING_MODE=json
```

## 基本用法

查看帮助：

```powershell
coding-agent --help
```

最小问答：

```powershell
coding-agent "解释一下什么是 coding agent"
```

分析当前仓库：

```powershell
coding-agent --workspace . --verbose "分析这个项目的架构"
```

只读代码审查：

```powershell
coding-agent --review "检查这个项目有哪些潜在问题"
```

输出 JSONL 审计日志：

```powershell
coding-agent --trace-file runs/latest.jsonl "总结这个项目"
```

输出 span 风格 trace：

```powershell
coding-agent --trace-format spans --trace-file runs/spans.jsonl "分析这个项目"
```

使用 MCP-compatible 工具适配层：

```powershell
coding-agent --tool-adapter mcp "列出项目主要文件"
```

在临时目录中运行白名单命令：

```powershell
coding-agent --command-mode temp "运行测试"
```

保存并恢复 session：

```powershell
coding-agent --session-id demo --history-db .coding-agent/sessions.sqlite "分析这个项目"
coding-agent --session-id demo --resume-session "继续上一次任务"
```

## Agent 协议

默认 JSON 协议：

```json
{"final": "给用户的最终回答"}
```

或：

```json
{"tool": "read_file", "args": {"path": "README.md"}}
```

V2 结构化动作协议支持：

```json
{"type": "tool_call", "tool": "read_file", "args": {"path": "README.md"}}
```

```json
{"type": "plan_update", "steps": ["读取项目结构", "分析核心模块", "总结结果"]}
```

```json
{"type": "review_finding", "file": "src/app.py", "line": 10, "severity": "high", "message": "这里存在潜在空指针问题"}
```

## 内置工具

只读工具：

- `list_files`：列出工作区文件。
- `read_file`：读取 UTF-8 文本文件。
- `search_text`：搜索文本。
- `summarize_workspace`：生成项目结构摘要。
- `search_code_chunks`：检索相关代码片段。

编辑工具：

- `write_file`：创建或覆盖文本文件。
- `apply_patch`：应用 unified diff patch。

命令工具：

- `run_command`：运行白名单命令。

当前允许的命令前缀包括：

- `python -m pytest`
- `python -m unittest`
- `python -m ruff check`
- `python -m mypy`
- `git diff`
- `git status`

## V2 模块说明

### 结构化动作协议

`src/coding_agent/v2/actions.py` 定义显式类型动作，使模型输出更容易校验和扩展。它支持最终回答、工具调用、计划更新、用户追问和审查发现。

### Context Engine

`src/coding_agent/v2/context.py` 将用户任务、仓库摘要、代码检索结果、历史摘要、当前计划、可用工具和 `AGENTS.md` 规则合成为上下文快照，减少模型盲目搜索，提高代码理解稳定性。

### 多阶段 Workflow

`src/coding_agent/v2/workflow.py` 将执行过程抽象为：

- Explore
- Plan
- Implement
- Verify
- Review
- Finalize

不同阶段对应不同工具权限，避免模型在不合适的阶段执行高风险操作。

### Guardrails

`src/coding_agent/v2/guardrails.py` 提供三层护栏：

- Input Guardrail：检查用户任务是否要求敏感信息或危险操作。
- Tool Guardrail：检查工具调用的路径、命令和当前阶段权限。
- Output Guardrail：检查最终输出是否合理。

风险等级分为：

- `low`
- `medium`
- `high`
- `blocked`

`blocked` 操作不会被 `--yes` 绕过。

### MCP-compatible Tool Adapter

`src/coding_agent/v2/tool_adapters.py` 提供：

- `DirectToolAdapter`：直接调用本地工具注册表。
- `LocalMcpServer`：进程内 MCP 风格工具路由器。
- `McpToolAdapter`：通过 MCP 风格协议调用工具。

第一版没有开放网络端口，重点是保留 MCP 兼容架构，同时保持本地执行安全。

### Trace Span

`src/coding_agent/v2/spans.py` 定义 span 事件模型，`audit.py` 中的 `JsonlSpanTracer` 可以把计划、模型响应、工具调用和最终输出写成 span 风格 JSONL，便于后续接入更完整的可观测性系统。

## 本地评测

运行离线评测：

```powershell
python evals\runner.py --offline
```

评测任务定义在：

```text
evals/tasks.yaml
```

当前覆盖：

- 仓库问答
- bug 定位
- 单文件修复
- 危险任务拒绝
- review findings 输出

## 测试

运行全量测试：

```powershell
python -m pytest
```

测试覆盖：

- Action 解析
- LLM Client
- Tool Registry
- 工具参数 Schema
- 文件安全边界
- 命令白名单
- 临时目录沙箱
- SQLite session history
- Code retrieval
- Trace / audit
- V2 context engine
- V2 guardrails
- V2 workflow
- V2 MCP-compatible adapter
- Eval harness

## 安全边界

项目默认遵循保守安全策略：

- 不读取 `.env`。
- 不修改 `.git`。
- 不允许路径逃逸到 workspace 外。
- 不开放任意 shell。
- 写文件和 patch 默认需要用户确认。
- Review Mode 只注册只读工具。
- 命令执行只允许白名单命令。
- `--command-mode temp` 可在临时目录副本中运行命令，避免污染原仓库。


