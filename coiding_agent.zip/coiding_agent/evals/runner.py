from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from pathlib import Path

from scorers import score_text_result


@dataclass(frozen=True)
class EvalTask:
    """本地评测任务定义。"""

    name: str
    prompt: str
    expected_contains: str | None = None
    blocked: bool = False


def load_tasks(path: Path) -> list[EvalTask]:
    """读取项目内置的极简 YAML 任务文件。"""
    tasks: list[dict[str, object]] = []
    current: dict[str, object] | None = None
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("- "):
            if current is not None:
                tasks.append(current)
            current = {}
            line = line[2:].strip()
            if line:
                key, value = _split_key_value(line)
                current[key] = value
            continue
        if current is None:
            continue
        key, value = _split_key_value(line)
        current[key] = value
    if current is not None:
        tasks.append(current)
    return [
        EvalTask(
            name=str(item["name"]),
            prompt=str(item["prompt"]),
            expected_contains=str(item["expected_contains"]) if "expected_contains" in item else None,
            blocked=str(item.get("blocked", "false")).lower() == "true",
        )
        for item in tasks
    ]


def run_offline(task: EvalTask) -> dict:
    """离线模式不调用模型，只验证评测框架本身。"""
    output = "Blocked by guardrail" if task.blocked else f"offline result for {task.prompt}"
    score = score_text_result(output, task.expected_contains, blocked=task.blocked)
    return {"name": task.name, "output": output, "score": score.to_dict()}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="运行本地 coding-agent 评测任务。")
    parser.add_argument("--tasks", default=str(Path(__file__).with_name("tasks.yaml")))
    parser.add_argument("--offline", action="store_true", help="运行确定性的离线评测。")
    args = parser.parse_args(argv)

    if not args.offline:
        print("第一版评测框架只实现 --offline。", file=sys.stderr)
        return 2

    results = [run_offline(task) for task in load_tasks(Path(args.tasks))]
    print(json.dumps({"results": results}, ensure_ascii=False, indent=2))
    return 0 if all(result["score"]["success"] for result in results) else 1


def _split_key_value(line: str) -> tuple[str, str]:
    key, _, value = line.partition(":")
    value = value.strip()
    if (value.startswith('"') and value.endswith('"')) or (value.startswith("'") and value.endswith("'")):
        value = value[1:-1]
    return key.strip(), value


if __name__ == "__main__":
    raise SystemExit(main())

