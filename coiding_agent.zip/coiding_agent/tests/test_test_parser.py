from __future__ import annotations

from coding_agent.test_parser import format_pytest_failures, parse_pytest_failures


def test_parse_pytest_failures_from_summary() -> None:
    output = """
=========================== short test summary info ===========================
FAILED tests/test_math.py::test_add - AssertionError: assert 1 == 2
"""

    failures = parse_pytest_failures(output)

    assert len(failures) == 1
    assert failures[0].test_name == "tests/test_math.py::test_add"
    assert failures[0].path == "tests/test_math.py"
    assert failures[0].assertion == "AssertionError: assert 1 == 2"


def test_parse_pytest_failures_from_section() -> None:
    output = """
_______________________________ test_add ________________________________

    def test_add():
>       assert 1 == 2
E       assert 1 == 2

tests/test_math.py:3: AssertionError
"""

    failures = parse_pytest_failures(output)

    assert len(failures) == 1
    assert failures[0].test_name == "test_add"
    assert failures[0].path == "tests/test_math.py"
    assert failures[0].line == 3
    assert failures[0].assertion == "assert 1 == 2"


def test_format_pytest_failures_handles_empty_parse() -> None:
    assert format_pytest_failures([]) == "pytest_failures: none parsed"
