from __future__ import annotations

import subprocess
from pathlib import Path

from coding_agent.tools import (
    ApplyPatchTool,
    ListFilesTool,
    ReadFileTool,
    RunCommandTool,
    SearchTextTool,
    WriteFileTool,
)
from coding_agent.tools.commands import summarize_command_output
from coding_agent.tools.editing import extract_patch_targets
from coding_agent.tools.indexing import SummarizeWorkspaceTool
from coding_agent.tools.factory import build_default_tools


def test_read_file_blocks_workspace_escape(tmp_path: Path) -> None:
    tool = ReadFileTool(tmp_path)

    result = tool.run({"path": "../outside.txt"})

    assert not result.ok
    assert "escapes workspace" in (result.error or "")


def test_read_file_blocks_sensitive_file(tmp_path: Path) -> None:
    (tmp_path / ".env").write_text("OPENAI_API_KEY=secret", encoding="utf-8")
    tool = ReadFileTool(tmp_path)

    result = tool.run({"path": ".env"})

    assert not result.ok
    assert "sensitive" in (result.error or "")


def test_readonly_tools(tmp_path: Path) -> None:
    (tmp_path / "README.md").write_text("hello agent\nsecond line", encoding="utf-8")

    listed = ListFilesTool(tmp_path).run({})
    read = ReadFileTool(tmp_path).run({"path": "README.md"})
    searched = SearchTextTool(tmp_path).run({"query": "agent"})

    assert listed.ok
    assert "README.md" in listed.content
    assert read.ok
    assert "hello agent" in read.content
    assert searched.ok
    assert "README.md:1" in searched.content


def test_run_command_blocks_unlisted_commands(tmp_path: Path) -> None:
    result = RunCommandTool(tmp_path).run({"command": "python -c \"print(1)\""})

    assert not result.ok
    assert "not allowed" in (result.error or "")


def test_run_command_allows_pytest_path_argument(tmp_path: Path) -> None:
    tests_dir = tmp_path / "tests"
    tests_dir.mkdir()
    result = RunCommandTool(tmp_path)._validate_command(("python", "-m", "pytest", "tests"))

    assert result == (True, "")


def test_run_command_blocks_workspace_escape_argument(tmp_path: Path) -> None:
    allowed, reason = RunCommandTool(tmp_path)._validate_command(("python", "-m", "pytest", "../outside"))

    assert not allowed
    assert "escapes workspace" in reason


def test_run_command_blocks_sensitive_argument(tmp_path: Path) -> None:
    allowed, reason = RunCommandTool(tmp_path)._validate_command(("python", "-m", "pytest", ".env"))

    assert not allowed
    assert "sensitive" in reason


def test_run_command_blocks_options(tmp_path: Path) -> None:
    allowed, reason = RunCommandTool(tmp_path)._validate_command(("python", "-m", "pytest", "-q"))

    assert not allowed
    assert "option" in reason


def test_summarize_command_output_includes_failure_summary() -> None:
    content = summarize_command_output(1, "normal output\n", "error one\nerror two\n")

    assert "summary=Command failed." in content
    assert "important_output:" in content
    assert "- error one" in content


def test_summarize_command_output_includes_pytest_failures() -> None:
    stdout = "FAILED tests/test_math.py::test_add - AssertionError: assert 1 == 2\n"

    content = summarize_command_output(1, stdout, "", ("python", "-m", "pytest"))

    assert "pytest_failures:" in content
    assert "tests/test_math.py::test_add" in content
    assert "AssertionError: assert 1 == 2" in content


def test_apply_patch_requires_unified_diff(tmp_path: Path) -> None:
    result = ApplyPatchTool(tmp_path, auto_yes=True).run({"patch_text": "not a patch"})

    assert not result.ok
    assert "unified diff" in (result.error or "")


def test_extract_patch_targets() -> None:
    patch = "diff --git a/hello.py b/hello.py\n--- a/hello.py\n+++ b/hello.py\n@@ -1 +1 @@\n-old\n+new\n"

    assert extract_patch_targets(patch) == ["hello.py"]


def test_apply_patch_blocks_sensitive_target(tmp_path: Path) -> None:
    patch = "diff --git a/.env b/.env\n--- a/.env\n+++ b/.env\n@@ -1 +1 @@\n-old\n+new\n"

    result = ApplyPatchTool(tmp_path, auto_yes=True).run({"patch_text": patch})

    assert not result.ok
    assert "sensitive" in (result.error or "")


def test_apply_patch_blocks_workspace_escape(tmp_path: Path) -> None:
    patch = "diff --git a/../escape.py b/../escape.py\n--- a/../escape.py\n+++ b/../escape.py\n@@ -1 +1 @@\n-old\n+new\n"

    result = ApplyPatchTool(tmp_path, auto_yes=True).run({"patch_text": patch})

    assert not result.ok
    assert "escapes workspace" in (result.error or "")


def test_apply_patch_applies_patch_and_returns_diff(tmp_path: Path) -> None:
    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True, text=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.name", "Test User"], cwd=tmp_path, check=True)
    file_path = tmp_path / "hello.py"
    file_path.write_text("print('old')\n", encoding="utf-8")
    subprocess.run(["git", "add", "hello.py"], cwd=tmp_path, check=True)
    subprocess.run(["git", "commit", "-m", "baseline"], cwd=tmp_path, check=True, capture_output=True, text=True)
    patch = (
        "diff --git a/hello.py b/hello.py\n"
        "--- a/hello.py\n"
        "+++ b/hello.py\n"
        "@@ -1 +1 @@\n"
        "-print('old')\n"
        "+print('new')\n"
    )

    result = ApplyPatchTool(tmp_path, auto_yes=True).run({"patch_text": patch})

    assert result.ok
    assert file_path.read_text(encoding="utf-8") == "print('new')\n"
    assert "print('new')" in result.content


def test_write_file_creates_text_file(tmp_path: Path) -> None:
    result = WriteFileTool(tmp_path, auto_yes=True).run({"path": "hello.py", "content": "print('hello world')\n"})

    assert result.ok
    assert (tmp_path / "hello.py").read_text(encoding="utf-8") == "print('hello world')\n"


def test_write_file_blocks_sensitive_file(tmp_path: Path) -> None:
    result = WriteFileTool(tmp_path, auto_yes=True).run({"path": ".env", "content": "SECRET=x\n"})

    assert not result.ok
    assert "sensitive" in (result.error or "")


def test_summarize_workspace_tool(tmp_path: Path) -> None:
    (tmp_path / "main.py").write_text("def main():\n    pass\n", encoding="utf-8")

    result = SummarizeWorkspaceTool(tmp_path).run({})

    assert result.ok
    assert "main.py" in result.content


def test_default_registry_validates_tool_args(tmp_path: Path) -> None:
    registry = build_default_tools(tmp_path, auto_yes=True)

    missing = registry.run("read_file", {})
    wrong_type = registry.run("write_file", {"path": "hello.py", "content": 123})
    unexpected = registry.run("summarize_workspace", {"path": "."})

    assert not missing.ok
    assert missing.error == "Missing required arg: path"
    assert not wrong_type.ok
    assert wrong_type.error == "Arg content must be string"
    assert not unexpected.ok
    assert unexpected.error == "Unexpected arg: path"


def test_run_command_temp_mode_does_not_modify_workspace(tmp_path: Path) -> None:
    tests = tmp_path / "tests"
    tests.mkdir()
    (tests / "test_side_effect.py").write_text(
        "from pathlib import Path\n\n"
        "def test_side_effect():\n"
        "    Path('created_by_test.txt').write_text('created', encoding='utf-8')\n",
        encoding="utf-8",
    )

    result = RunCommandTool(tmp_path, command_mode="temp").run({"command": "python -m pytest tests"})

    assert result.ok
    assert not (tmp_path / "created_by_test.txt").exists()
