from __future__ import annotations

from coding_agent.tools.factory import build_default_tools, build_review_tools


def test_build_default_tools_registers_expected_tools(tmp_path) -> None:  # type: ignore[no-untyped-def]
    registry = build_default_tools(tmp_path, auto_yes=True)
    descriptions = registry.descriptions()

    assert "list_files" in descriptions
    assert "read_file" in descriptions
    assert "search_text" in descriptions
    assert "summarize_workspace" in descriptions
    assert "search_code_chunks" in descriptions
    assert "write_file" in descriptions
    assert "apply_patch" in descriptions
    assert "run_command" in descriptions


def test_build_default_tools_exposes_function_specs(tmp_path) -> None:  # type: ignore[no-untyped-def]
    registry = build_default_tools(tmp_path, auto_yes=True)

    specs = registry.function_specs()

    names = {spec["name"] for spec in specs}
    assert "read_file" in names
    read_file = next(spec for spec in specs if spec["name"] == "read_file")
    assert read_file["parameters"]["required"] == ["path"]
    assert read_file["parameters"]["additionalProperties"] is False
    write_file = next(spec for spec in specs if spec["name"] == "write_file")
    assert write_file["parameters"]["required"] == ["path", "content"]


def test_build_review_tools_registers_only_readonly_tools(tmp_path) -> None:  # type: ignore[no-untyped-def]
    registry = build_review_tools(tmp_path)
    descriptions = registry.descriptions()

    assert "list_files" in descriptions
    assert "read_file" in descriptions
    assert "search_text" in descriptions
    assert "summarize_workspace" in descriptions
    assert "search_code_chunks" in descriptions
    assert "write_file" not in descriptions
    assert "apply_patch" not in descriptions
    assert "run_command" not in descriptions
