from __future__ import annotations

import pytest

from coding_agent.runtime.session_store import SessionNotFoundError, SessionStore


def test_session_store_writes_and_loads_summary(tmp_path) -> None:  # type: ignore[no-untyped-def]
    db = tmp_path / "history.sqlite"
    store = SessionStore(db)

    store.create_or_update_session("s1", tmp_path, "fix tests")
    store.append_event("s1", 0, "plan", {"steps": ["inspect"]})
    store.append_event("s1", 1, "tool_result", {"ok": True, "content": "done"})
    store.set_final("s1", "finished")

    summary = store.load_history_summary("s1")

    assert "session_id: s1" in summary
    assert "task: fix tests" in summary
    assert "final: finished" in summary
    assert "tool_result" in summary


def test_session_store_reports_missing_session(tmp_path) -> None:  # type: ignore[no-untyped-def]
    store = SessionStore(tmp_path / "history.sqlite")

    with pytest.raises(SessionNotFoundError, match="missing"):
        store.load_history_summary("missing")
