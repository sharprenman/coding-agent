from __future__ import annotations

import pytest

from coding_agent.config import (
    ConfigError,
    DEFAULT_API_MODE,
    DEFAULT_MODEL,
    DEFAULT_TOOL_CALLING_MODE,
    load_config,
    load_dotenv_file,
)


def test_load_config_requires_api_key(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    with pytest.raises(ConfigError):
        load_config()


def test_load_config_uses_default_model(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.delenv("OPENAI_MODEL", raising=False)
    monkeypatch.delenv("OPENAI_BASE_URL", raising=False)
    monkeypatch.delenv("OPENAI_API_MODE", raising=False)
    monkeypatch.delenv("TOOL_CALLING_MODE", raising=False)

    config = load_config()

    assert config.api_key == "test-key"
    assert config.model == DEFAULT_MODEL
    assert config.base_url is None
    assert config.api_mode == DEFAULT_API_MODE
    assert config.tool_calling_mode == DEFAULT_TOOL_CALLING_MODE


def test_load_config_reads_base_url(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("OPENAI_MODEL", "custom-model")
    monkeypatch.setenv("OPENAI_BASE_URL", "https://example.com/v1")
    monkeypatch.setenv("OPENAI_API_MODE", "chat_completions")
    monkeypatch.setenv("TOOL_CALLING_MODE", "native")

    config = load_config()

    assert config.api_key == "test-key"
    assert config.model == "custom-model"
    assert config.base_url == "https://example.com/v1"
    assert config.api_mode == "chat_completions"
    assert config.tool_calling_mode == "native"


def test_load_config_accepts_structured_tool_calling(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("TOOL_CALLING_MODE", "structured")

    config = load_config()

    assert config.tool_calling_mode == "structured"


def test_load_config_rejects_invalid_api_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("OPENAI_API_MODE", "invalid")

    with pytest.raises(ConfigError, match="OPENAI_API_MODE"):
        load_config()


def test_load_config_rejects_invalid_tool_calling_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("TOOL_CALLING_MODE", "invalid")

    with pytest.raises(ConfigError, match="TOOL_CALLING_MODE"):
        load_config()


def test_load_dotenv_file_reads_env_file(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("OPENAI_MODEL", raising=False)
    env_file = tmp_path / ".env"
    env_file.write_text(
        "OPENAI_API_KEY=from-env-file\nOPENAI_MODEL=env-model\nOPENAI_API_MODE=chat_completions\n",
        encoding="utf-8",
    )

    load_dotenv_file(env_file)

    assert load_config().api_key == "from-env-file"
    assert load_config().model == "env-model"
    assert load_config().api_mode == "chat_completions"


def test_dotenv_does_not_override_existing_env(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("OPENAI_API_KEY", "from-shell")
    env_file = tmp_path / ".env"
    env_file.write_text("OPENAI_API_KEY=from-env-file\n", encoding="utf-8")

    load_dotenv_file(env_file)

    assert load_config().api_key == "from-shell"
