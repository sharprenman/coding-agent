from __future__ import annotations

from dataclasses import dataclass

from coding_agent.agent import Agent
from coding_agent.tracing import MemoryTracer
from coding_agent.tools import ToolRegistry, ToolResult


class FakeLLM:
    def __init__(self, responses: list[str]) -> None:
        self.responses = responses
        self.inputs: list[str] = []
        self.instructions: list[str] = []

    def respond(self, instructions: str, user_input: str) -> str:
        self.instructions.append(instructions)
        self.inputs.append(user_input)
        return self.responses.pop(0)


@dataclass
class EchoTool:
    name: str = "echo"
    description: str = "Echo input."

    def run(self, args: dict) -> ToolResult:
        return ToolResult(True, f"echo:{args.get('value')}")


def test_agent_returns_final_response() -> None:
    registry = ToolRegistry()
    agent = Agent(FakeLLM(['{"final": "done"}']), registry)

    assert agent.run("hello") == "done"


def test_agent_runs_tool_then_returns_final() -> None:
    registry = ToolRegistry()
    registry.register(EchoTool())
    llm = FakeLLM(['{"tool": "echo", "args": {"value": "x"}}', '{"final": "finished"}'])
    agent = Agent(llm, registry, max_steps=2)

    assert agent.run("use tool") == "finished"
    assert "echo:x" in llm.inputs[-1]
    assert agent.last_memory is not None
    assert agent.last_memory.plan is not None
    assert agent.last_memory.observations[0].content == "echo:x"


def test_agent_stops_at_max_steps() -> None:
    registry = ToolRegistry()
    agent = Agent(FakeLLM(['{"tool": "missing", "args": {}}']), registry, max_steps=1)

    assert agent.run("loop").startswith("Stopped after 1 steps")


def test_agent_reports_invalid_action_to_model() -> None:
    registry = ToolRegistry()
    llm = FakeLLM(["not json", '{"final": "recovered"}'])
    agent = Agent(llm, registry, max_steps=2)

    assert agent.run("recover") == "recovered"
    assert "Invalid JSON" in llm.inputs[-1]


def test_agent_stops_after_consecutive_invalid_actions() -> None:
    registry = ToolRegistry()
    llm = FakeLLM(["not json", "still not json"])
    agent = Agent(llm, registry, max_steps=5, max_errors=2)

    assert agent.run("fail").startswith("Stopped after 2 consecutive errors")


def test_agent_stops_after_consecutive_tool_errors() -> None:
    registry = ToolRegistry()
    llm = FakeLLM(['{"tool": "missing", "args": {}}', '{"tool": "missing", "args": {}}'])
    agent = Agent(llm, registry, max_steps=5, max_errors=2)

    assert agent.run("fail").startswith("Stopped after 2 consecutive errors")


def test_agent_traces_tool_flow() -> None:
    registry = ToolRegistry()
    registry.register(EchoTool())
    tracer = MemoryTracer()
    llm = FakeLLM(['{"tool": "echo", "args": {"value": "x"}}', '{"final": "finished"}'])
    agent = Agent(llm, registry, max_steps=2, tracer=tracer)

    assert agent.run("use tool") == "finished"
    assert tracer.events == [
        "plan:['理解用户任务和当前限制', '完成任务后返回简洁最终结果']",
        'model_response:1:{"tool": "echo", "args": {"value": "x"}}',
        "tool_request:1:echo:{'value': 'x'}",
        "tool_result:1:True:None",
        'model_response:2:{"final": "finished"}',
        "final:2:finished",
    ]


def test_agent_uses_review_prompt() -> None:
    registry = ToolRegistry()
    llm = FakeLLM(['{"final": "reviewed"}'])
    agent = Agent(llm, registry, review_mode=True)

    assert agent.run("review") == "reviewed"
    assert "Review Mode" in llm.instructions[0]
