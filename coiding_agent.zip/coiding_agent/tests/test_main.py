from __future__ import annotations

from coding_agent import main as main_module
from coding_agent.main import main


def test_cli_empty_input_shows_help(capsys) -> None:  # type: ignore[no-untyped-def]
    exit_code = main([])

    captured = capsys.readouterr()
    assert exit_code == 2
    assert "usage:" in captured.out


def test_cli_accepts_verbose_flag_without_task(capsys) -> None:  # type: ignore[no-untyped-def]
    exit_code = main(["--verbose"])

    captured = capsys.readouterr()
    assert exit_code == 2
    assert "--verbose" in captured.out
    assert "--max-errors" in captured.out
    assert "--trace-file" in captured.out
    assert "--review" in captured.out
    assert "--session-id" in captured.out
    assert "--command-mode" in captured.out


def test_cli_passes_verbose_tracer(monkeypatch, tmp_path, capsys) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    class FakeLLMClient:
        def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
            pass

        def respond(self, instructions: str, user_input: str) -> str:
            return '{"final": "done"}'

    monkeypatch.setattr(main_module, "LLMClient", FakeLLMClient)

    exit_code = main(["--verbose", "hello"])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "[step 1] model returned final" in captured.out
    assert "done" in captured.out


def test_cli_writes_trace_file(monkeypatch, tmp_path, capsys) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    class FakeLLMClient:
        def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
            pass

        def respond(self, instructions: str, user_input: str) -> str:
            return '{"final": "done"}'

    monkeypatch.setattr(main_module, "LLMClient", FakeLLMClient)
    trace_file = tmp_path / "runs" / "latest.jsonl"

    exit_code = main(["--trace-file", str(trace_file), "hello"])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "done" in captured.out
    events = [line for line in trace_file.read_text(encoding="utf-8").splitlines()]
    assert any('"type": "model_response"' in event for event in events)
    assert any('"type": "final"' in event for event in events)


def test_cli_supports_verbose_and_trace_file_together(monkeypatch, tmp_path, capsys) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    class FakeLLMClient:
        def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
            pass

        def respond(self, instructions: str, user_input: str) -> str:
            return '{"final": "done"}'

    monkeypatch.setattr(main_module, "LLMClient", FakeLLMClient)
    trace_file = tmp_path / "runs" / "latest.jsonl"

    exit_code = main(["--verbose", "--trace-file", str(trace_file), "hello"])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "[step 1] model returned final" in captured.out
    events = [line for line in trace_file.read_text(encoding="utf-8").splitlines()]
    assert any('"type": "model_response"' in event for event in events)
    assert any('"type": "final"' in event for event in events)


def test_cli_passes_native_tool_calling_config(monkeypatch, tmp_path, capsys) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    monkeypatch.setenv("TOOL_CALLING_MODE", "native")
    init_kwargs = {}

    class FakeLLMClient:
        def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
            init_kwargs.update(kwargs)

        def respond(self, instructions: str, user_input: str) -> str:
            return '{"final": "done"}'

    monkeypatch.setattr(main_module, "LLMClient", FakeLLMClient)

    exit_code = main(["hello"])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "done" in captured.out
    assert init_kwargs["tool_calling_mode"] == "native"
    assert any(tool["name"] == "read_file" for tool in init_kwargs["tools"])


def test_cli_review_mode_uses_readonly_tools_and_review_prompt(monkeypatch, tmp_path, capsys) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    seen = {}

    class FakeLLMClient:
        def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
            seen["tools"] = kwargs["tools"]

        def respond(self, instructions: str, user_input: str) -> str:
            seen["instructions"] = instructions
            return '{"final": "no findings"}'

    monkeypatch.setattr(main_module, "LLMClient", FakeLLMClient)

    exit_code = main(["--review", "检查项目"])

    captured = capsys.readouterr()
    tool_names = {tool["name"] for tool in seen["tools"]}
    assert exit_code == 0
    assert "no findings" in captured.out
    assert "Review Mode" in seen["instructions"]
    assert {"list_files", "read_file", "search_text", "summarize_workspace"} <= tool_names
    assert "write_file" not in tool_names
    assert "apply_patch" not in tool_names
    assert "run_command" not in tool_names


def test_cli_resume_session_requires_session_id(capsys) -> None:  # type: ignore[no-untyped-def]
    exit_code = main(["--resume-session", "hello"])

    captured = capsys.readouterr()
    assert exit_code == 2
    assert "--resume-session requires --session-id" in captured.err


def test_cli_resume_session_passes_history_to_model(monkeypatch, tmp_path, capsys) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")
    from coding_agent.runtime.session_store import SessionStore

    db = tmp_path / "sessions.sqlite"
    store = SessionStore(db)
    store.create_or_update_session("s1", tmp_path, "old task")
    store.set_final("s1", "old final")
    seen = {}

    class FakeLLMClient:
        def __init__(self, **kwargs) -> None:  # type: ignore[no-untyped-def]
            pass

        def respond(self, instructions: str, user_input: str) -> str:
            seen["user_input"] = user_input
            return '{"final": "new final"}'

    monkeypatch.setattr(main_module, "LLMClient", FakeLLMClient)

    exit_code = main(["--session-id", "s1", "--resume-session", "--history-db", str(db), "new task"])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "new final" in captured.out
    assert "Previous session summary:" in seen["user_input"]
    assert "old final" in seen["user_input"]
