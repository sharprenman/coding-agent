from __future__ import annotations

from coding_agent.memory import AgentMemory, Observation
from coding_agent.planner import Plan


def test_observation_to_prompt_text() -> None:
    observation = Observation(step=1, ok=True, content="done", error=None)

    text = observation.to_prompt_text()

    assert "Tool observation:" in text
    assert '"step": 1' in text
    assert '"ok": true' in text
    assert '"content": "done"' in text


def test_agent_memory_builds_model_input() -> None:
    memory = AgentMemory(user_task="read README")
    memory.set_plan(Plan(["inspect files", "answer user"]))
    memory.add_observation(1, True, "README content", None)

    text = memory.to_model_input()

    assert "User task:\nread README" in text
    assert "Plan:" in text
    assert "1. inspect files" in text
    assert "Tool observation:" in text
    assert "README content" in text
