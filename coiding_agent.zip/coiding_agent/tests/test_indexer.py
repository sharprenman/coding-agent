from __future__ import annotations

from coding_agent.indexer import summarize_workspace


def test_summarize_workspace_finds_key_files_entrypoints_and_symbols(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / "README.md").write_text("# Demo\n", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text("[project]\nname='demo'\n", encoding="utf-8")
    src = tmp_path / "src"
    src.mkdir()
    app = src / "main.py"
    app.write_text(
        "class App:\n    pass\n\n"
        "def run():\n    return None\n",
        encoding="utf-8",
    )

    summary = summarize_workspace(tmp_path)

    assert summary.file_count == 3
    assert ".py" in summary.file_types
    assert "README.md" in summary.key_files
    assert "pyproject.toml" in summary.key_files
    assert "src/main.py" in summary.entrypoints
    assert summary.python_symbols[0].classes == ["App"]
    assert summary.python_symbols[0].functions == ["run"]


def test_summarize_workspace_skips_sensitive_files(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / ".env").write_text("SECRET=x\n", encoding="utf-8")
    (tmp_path / "safe.py").write_text("def ok():\n    pass\n", encoding="utf-8")

    summary = summarize_workspace(tmp_path)

    assert summary.file_count == 1
    assert summary.python_symbols[0].path == "safe.py"


def test_workspace_summary_to_text(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / "main.py").write_text("def main():\n    pass\n", encoding="utf-8")

    text = summarize_workspace(tmp_path).to_text()

    assert "files: 1" in text
    assert "entrypoints:" in text
    assert "main.py" in text
    assert "project_intelligence:" in text
    assert "architecture_summary:" in text
