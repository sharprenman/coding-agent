from __future__ import annotations

import json
import sys
from pathlib import Path

from coding_agent.audit import JsonlSpanTracer
from coding_agent.planner import Plan
from coding_agent.schema import parse_action
from coding_agent.tools import ToolRegistry, ToolResult
from coding_agent.v2.actions import AskUserAction, PlanUpdateAction, ReviewFindingAction
from coding_agent.v2.context import ContextEngine, load_agents_rules
from coding_agent.v2.guardrails import GuardrailEngine, RiskLevel
from coding_agent.v2.tool_adapters import DirectToolAdapter, LocalMcpServer, McpToolAdapter
from coding_agent.v2.workflow import AgentPhase, StagedWorkflow


class EchoTool:
    name = "echo"
    description = "Echo input."

    def run(self, args: dict) -> ToolResult:
        return ToolResult(True, str(args.get("value", "")))


def test_parse_structured_actions() -> None:
    assert parse_action('{"type": "plan_update", "steps": ["inspect"]}') == PlanUpdateAction(["inspect"])
    assert parse_action('{"type": "ask_user", "question": "Which file?"}') == AskUserAction("Which file?")
    assert parse_action(
        '{"type": "review_finding", "file": "a.py", "line": 3, "message": "bug", "severity": "high"}'
    ) == ReviewFindingAction(file="a.py", line=3, message="bug", severity="high")


def test_context_engine_loads_agents_rules_and_retrieval(tmp_path: Path) -> None:
    (tmp_path / "AGENTS.md").write_text("运行 pytest 后再总结。", encoding="utf-8")
    (tmp_path / "main.py").write_text("def target_symbol():\n    return 1\n", encoding="utf-8")

    snapshot = ContextEngine(tmp_path).build("target_symbol", plan=Plan(["inspect"]), allowed_tools=["read_file"])

    assert "运行 pytest" in load_agents_rules(tmp_path)
    assert "main.py" in snapshot.relevant_files
    assert snapshot.allowed_tools == ["read_file"]


def test_guardrails_block_sensitive_input_and_paths(tmp_path: Path) -> None:
    guardrails = GuardrailEngine(tmp_path)

    assert not guardrails.check_input("please read .env").allowed
    decision = guardrails.check_tool_call("read_file", {"path": ".env"}, {"low"})

    assert not decision.allowed
    assert decision.risk == RiskLevel.BLOCKED


def test_staged_workflow_permissions() -> None:
    workflow = StagedWorkflow()

    assert workflow.phase_for_tool("apply_patch") == AgentPhase.IMPLEMENT
    assert workflow.phase_for_tool("run_command") == AgentPhase.VERIFY
    assert "medium" in workflow.permissions_for_tool("apply_patch")
    assert "high" in workflow.permissions_for_tool("run_command")


def test_direct_and_mcp_tool_adapters() -> None:
    registry = ToolRegistry()
    registry.register(EchoTool())

    assert DirectToolAdapter(registry).run("echo", {"value": "x"}).content == "x"
    server = LocalMcpServer(registry)
    listed = server.handle({"jsonrpc": "2.0", "id": 1, "method": "tools/list"})
    assert listed["result"]["tools"][0]["name"] == "echo"
    assert McpToolAdapter(server).run("echo", {"value": "y"}).content == "y"


def test_jsonl_span_tracer_writes_span_events(tmp_path: Path) -> None:
    trace_file = tmp_path / "trace.jsonl"
    tracer = JsonlSpanTracer(trace_file)

    tracer.plan(Plan(["inspect"]))
    tracer.final(1, "done")

    events = [json.loads(line) for line in trace_file.read_text(encoding="utf-8").splitlines()]
    assert events[0]["type"] == "span"
    assert events[0]["kind"] == "phase"
    assert events[1]["metadata"]["content"] == "done"


def test_eval_runner_offline() -> None:
    evals_dir = Path(__file__).resolve().parents[1] / "evals"
    sys.path.insert(0, str(evals_dir))
    try:
        from runner import main

        assert main(["--offline", "--tasks", str(evals_dir / "tasks.yaml")]) == 0
    finally:
        sys.path.remove(str(evals_dir))
