from __future__ import annotations

from coding_agent.runtime.retrieval import CodeChunkIndex
from coding_agent.tools.retrieval import SearchCodeChunksTool


def test_code_chunk_index_searches_text_and_paths(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / "README.md").write_text("agent memory retrieval\n", encoding="utf-8")
    src = tmp_path / "src"
    src.mkdir()
    (src / "app.py").write_text("def load_memory():\n    return 'memory'\n", encoding="utf-8")

    index = CodeChunkIndex.build(tmp_path)

    results = index.search("memory", limit=5)

    assert results
    assert results[0].score > 0
    assert {result.path for result in results} == {"README.md", "src/app.py"}


def test_code_chunk_index_skips_sensitive_and_binary_files(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / ".env").write_text("SECRET=memory\n", encoding="utf-8")
    (tmp_path / "image.bin").write_bytes(b"\x00\x01memory")
    (tmp_path / "safe.py").write_text("def memory():\n    pass\n", encoding="utf-8")

    results = CodeChunkIndex.build(tmp_path).search("memory")

    assert [result.path for result in results] == ["safe.py"]


def test_search_code_chunks_tool_returns_locations(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / "main.py").write_text("def run_agent():\n    return 'agent'\n", encoding="utf-8")

    result = SearchCodeChunksTool(tmp_path).run({"query": "run_agent"})

    assert result.ok
    assert "main.py:1-2" in result.content
