from __future__ import annotations

import json

from coding_agent.audit import JsonlAuditTracer
from coding_agent.planner import Plan
from coding_agent.tools import ToolResult


def read_events(path):  # type: ignore[no-untyped-def]
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]


def test_jsonl_audit_tracer_writes_agent_events(tmp_path) -> None:  # type: ignore[no-untyped-def]
    trace_file = tmp_path / "runs" / "latest.jsonl"
    tracer = JsonlAuditTracer(trace_file)

    tracer.plan(Plan(["inspect", "answer"]))
    tracer.model_response(1, '{"tool": "echo", "args": {"value": "x"}}')
    tracer.tool_request(1, "echo", {"value": "x"})
    tracer.tool_result(1, ToolResult(ok=True, content="echo:x"))
    tracer.final(2, "done")

    assert read_events(trace_file) == [
        {"type": "plan", "steps": ["inspect", "answer"]},
        {"type": "model_response", "step": 1, "content": '{"tool": "echo", "args": {"value": "x"}}'},
        {"type": "tool_call", "step": 1, "tool": "echo", "args": {"value": "x"}},
        {"type": "tool_result", "step": 1, "ok": True, "content": "echo:x", "error": None},
        {"type": "final", "step": 2, "content": "done"},
    ]


def test_jsonl_audit_tracer_starts_with_empty_file(tmp_path) -> None:  # type: ignore[no-untyped-def]
    trace_file = tmp_path / "latest.jsonl"
    trace_file.write_text('{"type": "old"}\n', encoding="utf-8")

    tracer = JsonlAuditTracer(trace_file)
    tracer.final(1, "new")

    assert read_events(trace_file) == [{"type": "final", "step": 1, "content": "new"}]
