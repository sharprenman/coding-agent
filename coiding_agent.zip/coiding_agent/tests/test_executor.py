from __future__ import annotations

from dataclasses import dataclass

from coding_agent.executor import Executor
from coding_agent.schema import ToolAction
from coding_agent.tools import ToolRegistry, ToolResult
from coding_agent.tracing import MemoryTracer


@dataclass
class EchoTool:
    name: str = "echo"
    description: str = "Echo input."

    def run(self, args: dict) -> ToolResult:
        return ToolResult(True, f"echo:{args.get('value')}")


def test_executor_runs_tool_and_traces_result() -> None:
    registry = ToolRegistry()
    registry.register(EchoTool())
    tracer = MemoryTracer()
    executor = Executor(registry, tracer)

    result = executor.execute(1, ToolAction(tool="echo", args={"value": "x"}))

    assert result == ToolResult(True, "echo:x")
    assert tracer.events == [
        "tool_request:1:echo:{'value': 'x'}",
        "tool_result:1:True:None",
    ]
