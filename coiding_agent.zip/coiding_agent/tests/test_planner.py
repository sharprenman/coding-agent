from __future__ import annotations

from coding_agent.planner import Plan, SimplePlanner


def test_plan_to_prompt_text() -> None:
    plan = Plan(["inspect", "answer"])

    assert plan.to_prompt_text() == "Plan:\n1. inspect\n2. answer"


def test_simple_planner_adds_file_step_for_file_tasks() -> None:
    plan = SimplePlanner().plan("创建一个 python 文件")

    assert "必要时查看或修改工作区文件" in plan.steps
    assert plan.steps[-1] == "完成任务后返回简洁最终结果"


def test_simple_planner_treats_python_keyword_as_file_task() -> None:
    plan = SimplePlanner().plan("create a python script")

    assert "必要时查看或修改工作区文件" in plan.steps


def test_simple_planner_adds_command_step_for_test_tasks() -> None:
    plan = SimplePlanner().plan("运行 pytest")

    assert "必要时运行允许的验证命令" in plan.steps
