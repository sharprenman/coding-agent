from __future__ import annotations

from coding_agent.runtime.sandbox import SandboxRunner


def test_sandbox_runner_temp_mode_does_not_modify_workspace(tmp_path) -> None:  # type: ignore[no-untyped-def]
    tests = tmp_path / "tests"
    tests.mkdir()
    (tests / "test_side_effect.py").write_text(
        "from pathlib import Path\n\n"
        "def test_side_effect():\n"
        "    Path('created_by_test.txt').write_text('created', encoding='utf-8')\n",
        encoding="utf-8",
    )

    result = SandboxRunner().run(("python", "-m", "pytest", "tests"), tmp_path, "temp", 30)

    assert result.returncode == 0
    assert not (tmp_path / "created_by_test.txt").exists()


def test_sandbox_runner_workspace_mode_keeps_existing_behavior(tmp_path) -> None:  # type: ignore[no-untyped-def]
    tests = tmp_path / "tests"
    tests.mkdir()
    (tests / "test_side_effect.py").write_text(
        "from pathlib import Path\n\n"
        "def test_side_effect():\n"
        "    Path('created_by_test.txt').write_text('created', encoding='utf-8')\n",
        encoding="utf-8",
    )

    result = SandboxRunner().run(("python", "-m", "pytest", "tests"), tmp_path, "workspace", 30)

    assert result.returncode == 0
    assert (tmp_path / "created_by_test.txt").exists()
