from __future__ import annotations

from coding_agent.code_intelligence import analyze_project


def test_analyze_project_reads_dependencies_imports_and_source_roots(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / "pyproject.toml").write_text(
        "[project]\n"
        "dependencies = ['openai>=1.0.0']\n"
        "[project.optional-dependencies]\n"
        "dev = ['pytest>=8.0.0']\n",
        encoding="utf-8",
    )
    (tmp_path / "requirements.txt").write_text("python-dotenv>=1.0.0\n", encoding="utf-8")
    package = tmp_path / "src" / "demo"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("", encoding="utf-8")
    (package / "app.py").write_text("import os\nfrom pathlib import Path\n", encoding="utf-8")

    intelligence = analyze_project(tmp_path)

    assert intelligence.dependencies == ["openai", "pytest", "python-dotenv"]
    assert "src" in intelligence.source_roots
    assert "src/demo" in intelligence.source_roots
    app_imports = next(item for item in intelligence.imports if item.path == "src/demo/app.py")
    assert app_imports.imports == ["os", "pathlib"]
    assert any("pyproject.toml" in item for item in intelligence.architecture_summary)


def test_analyze_project_maps_tests_to_sources(tmp_path) -> None:  # type: ignore[no-untyped-def]
    src = tmp_path / "src" / "demo"
    tests = tmp_path / "tests"
    src.mkdir(parents=True)
    tests.mkdir()
    (src / "agent.py").write_text("class Agent:\n    pass\n", encoding="utf-8")
    (tests / "test_agent.py").write_text("from demo.agent import Agent\n", encoding="utf-8")
    (tests / "test_missing.py").write_text("def test_missing():\n    pass\n", encoding="utf-8")

    intelligence = analyze_project(tmp_path)

    mappings = {mapping.test_path: mapping.source_path for mapping in intelligence.test_mappings}
    assert mappings["tests/test_agent.py"] == "src/demo/agent.py"
    assert mappings["tests/test_missing.py"] is None


def test_analyze_project_skips_invalid_python_imports(tmp_path) -> None:  # type: ignore[no-untyped-def]
    (tmp_path / "broken.py").write_text("def broken(:\n", encoding="utf-8")

    intelligence = analyze_project(tmp_path)

    assert intelligence.imports[0].path == "broken.py"
    assert intelligence.imports[0].imports == []
