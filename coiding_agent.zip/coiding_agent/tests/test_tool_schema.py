from __future__ import annotations

from dataclasses import dataclass

from coding_agent.tools import ToolRegistry, ToolResult
from coding_agent.tools.schema import ToolArg, ToolArgsSchema


def test_tool_args_schema_generates_json_schema() -> None:
    schema = ToolArgsSchema(
        args=(
            ToolArg(name="path", type="string", description="Path to read.", required=True),
            ToolArg(name="recursive", type="boolean", description="Whether to recurse."),
        )
    )

    assert schema.to_json_schema() == {
        "type": "object",
        "properties": {
            "path": {"type": "string", "description": "Path to read."},
            "recursive": {"type": "boolean", "description": "Whether to recurse."},
        },
        "additionalProperties": False,
        "required": ["path"],
    }


def test_tool_args_schema_validates_required_and_types() -> None:
    schema = ToolArgsSchema(args=(ToolArg(name="path", type="string", description="Path.", required=True),))

    assert schema.validate({}) == "Missing required arg: path"
    assert schema.validate({"path": 123}) == "Arg path must be string"
    assert schema.validate({"path": "README.md"}) is None


def test_tool_args_schema_rejects_extra_args_by_default() -> None:
    schema = ToolArgsSchema(args=(ToolArg(name="path", type="string", description="Path."),))

    assert schema.validate({"path": "README.md", "extra": "x"}) == "Unexpected arg: extra"


def test_tool_args_schema_can_allow_extra_args() -> None:
    schema = ToolArgsSchema(args=(), allow_extra=True)

    assert schema.validate({"extra": "x"}) is None


@dataclass
class StrictTool:
    name: str = "strict"
    description: str = "Strict test tool."
    args_schema: ToolArgsSchema = ToolArgsSchema(
        args=(ToolArg(name="value", type="string", description="Value.", required=True),)
    )
    calls: int = 0

    def run(self, args: dict) -> ToolResult:
        self.calls += 1
        return ToolResult(True, args["value"])


def test_registry_validates_args_before_running_tool() -> None:
    tool = StrictTool()
    registry = ToolRegistry()
    registry.register(tool)

    result = registry.run("strict", {"value": 1})

    assert result == ToolResult(False, "", "Arg value must be string")
    assert tool.calls == 0


def test_registry_runs_tool_after_schema_validation() -> None:
    tool = StrictTool()
    registry = ToolRegistry()
    registry.register(tool)

    result = registry.run("strict", {"value": "ok"})

    assert result == ToolResult(True, "ok")
    assert tool.calls == 1
