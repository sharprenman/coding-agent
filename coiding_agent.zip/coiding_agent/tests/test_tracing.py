from __future__ import annotations

from coding_agent.tracing import ConsoleTracer
from coding_agent.planner import Plan
from coding_agent.tools import ToolResult


def test_console_tracer_summarizes_write_file_args(capsys) -> None:  # type: ignore[no-untyped-def]
    tracer = ConsoleTracer()
    long_content = "print('hello world')\n" * 20

    tracer.tool_request(1, "write_file", {"path": "snake_game.py", "content": long_content})

    captured = capsys.readouterr()
    assert "write_file" in captured.out
    assert "path=snake_game.py" in captured.out
    assert f"content_length={len(long_content)}" in captured.out
    assert "print('hello world')" not in captured.out


def test_console_tracer_prints_plan(capsys) -> None:  # type: ignore[no-untyped-def]
    tracer = ConsoleTracer()

    tracer.plan(Plan(["inspect", "answer"]))

    captured = capsys.readouterr()
    assert "[plan]" in captured.out
    assert "1. inspect" in captured.out


def test_console_tracer_summarizes_model_tool_response(capsys) -> None:  # type: ignore[no-untyped-def]
    tracer = ConsoleTracer()
    long_content = "x" * 200

    tracer.model_response(1, '{"tool": "write_file", "args": {"path": "demo.py", "content": "' + long_content + '"}}')

    captured = capsys.readouterr()
    assert "tool=write_file" in captured.out
    assert "path=demo.py" in captured.out
    assert "content_length=200" in captured.out
    assert long_content not in captured.out


def test_console_tracer_summarizes_tool_result(capsys) -> None:  # type: ignore[no-untyped-def]
    tracer = ConsoleTracer()

    tracer.tool_result(1, ToolResult(ok=True, content="Wrote snake_game.py"))

    captured = capsys.readouterr()
    assert "[step 1] tool result: ok Wrote snake_game.py" in captured.out
