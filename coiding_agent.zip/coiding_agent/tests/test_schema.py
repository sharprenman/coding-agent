from __future__ import annotations

from coding_agent.schema import FinalAction, InvalidAction, ToolAction, extract_json_object, parse_action


def test_parse_final_action() -> None:
    action = parse_action('{"final": "done"}')

    assert action == FinalAction(final="done")


def test_parse_tool_action() -> None:
    action = parse_action('{"tool": "read_file", "args": {"path": "README.md"}}')

    assert action == ToolAction(tool="read_file", args={"path": "README.md"})


def test_parse_tool_action_defaults_args() -> None:
    action = parse_action('{"tool": "list_files"}')

    assert action == ToolAction(tool="list_files", args={})


def test_parse_rejects_invalid_json() -> None:
    action = parse_action("not json")

    assert isinstance(action, InvalidAction)
    assert "Invalid JSON" in action.error


def test_parse_rejects_non_object() -> None:
    action = parse_action('["final"]')

    assert isinstance(action, InvalidAction)
    assert "JSON object" in action.error


def test_parse_rejects_both_final_and_tool() -> None:
    action = parse_action('{"final": "done", "tool": "read_file"}')

    assert isinstance(action, InvalidAction)
    assert "both final and tool" in action.error


def test_parse_rejects_missing_action_key() -> None:
    action = parse_action('{"message": "done"}')

    assert isinstance(action, InvalidAction)
    assert "final or tool" in action.error


def test_parse_rejects_non_string_final() -> None:
    action = parse_action('{"final": 123}')

    assert isinstance(action, InvalidAction)
    assert "final must be a string" in action.error


def test_parse_rejects_non_string_tool() -> None:
    action = parse_action('{"tool": 123, "args": {}}')

    assert isinstance(action, InvalidAction)
    assert "tool must be a string" in action.error


def test_parse_rejects_non_object_args() -> None:
    action = parse_action('{"tool": "read_file", "args": []}')

    assert isinstance(action, InvalidAction)
    assert "args must be an object" in action.error


def test_parse_extracts_json_from_markdown_code_block() -> None:
    action = parse_action('```json\n{"final": "done"}\n```')

    assert action == FinalAction(final="done")


def test_parse_extracts_json_from_wrapped_text() -> None:
    action = parse_action('好的，结果如下：{"final": "done"}')

    assert action == FinalAction(final="done")


def test_extract_json_object_handles_nested_strings() -> None:
    raw = 'prefix {"tool": "write_file", "args": {"content": "print({})"}} suffix'

    assert extract_json_object(raw) == '{"tool": "write_file", "args": {"content": "print({})"}}'
