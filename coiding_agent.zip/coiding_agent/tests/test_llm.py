from __future__ import annotations

from types import SimpleNamespace

from coding_agent.llm import LLMClient


class FakeResponses:
    def __init__(self, response=None) -> None:  # type: ignore[no-untyped-def]
        self.calls: list[dict] = []
        self.response = response

    def create(self, **kwargs):  # type: ignore[no-untyped-def]
        self.calls.append(kwargs)
        if self.response is not None:
            return self.response
        return SimpleNamespace(output_text="responses result")


class FakeChatCompletions:
    def __init__(self, response=None) -> None:  # type: ignore[no-untyped-def]
        self.calls: list[dict] = []
        self.response = response

    def create(self, **kwargs):  # type: ignore[no-untyped-def]
        self.calls.append(kwargs)
        if self.response is not None:
            return self.response
        message = SimpleNamespace(content="chat result")
        choice = SimpleNamespace(message=message)
        return SimpleNamespace(choices=[choice])


def make_client(api_mode: str, tool_calling_mode: str = "json", tools=None, responses_response=None, chat_response=None):  # type: ignore[no-untyped-def]
    client = LLMClient.__new__(LLMClient)
    client._model = "test-model"
    client._api_mode = api_mode
    client._tool_calling_mode = tool_calling_mode
    client._tools = tools or []
    client._client = SimpleNamespace(
        responses=FakeResponses(responses_response),
        chat=SimpleNamespace(completions=FakeChatCompletions(chat_response)),
    )
    return client


def test_llm_client_uses_responses_mode() -> None:
    client = make_client("responses")

    result = client.respond("system prompt", "hello")

    assert result == "responses result"
    assert client._client.responses.calls[0]["instructions"] == "system prompt"
    assert client._client.responses.calls[0]["input"] == "hello"


def test_llm_client_uses_chat_completions_mode() -> None:
    client = make_client("chat_completions")

    result = client.respond("system prompt", "hello")

    assert result == "chat result"
    messages = client._client.chat.completions.calls[0]["messages"]
    assert messages == [
        {"role": "system", "content": "system prompt"},
        {"role": "user", "content": "hello"},
    ]


def test_llm_client_uses_responses_native_tool_calling() -> None:
    response = SimpleNamespace(
        output=[
            SimpleNamespace(
                type="function_call",
                name="read_file",
                arguments='{"path": "README.md"}',
            )
        ],
        output_text="",
    )
    client = make_client(
        "responses",
        tool_calling_mode="native",
        tools=[{"name": "read_file", "description": "Read file", "parameters": {"type": "object"}}],
        responses_response=response,
    )

    result = client.respond("system prompt", "hello")

    assert result == '{"tool": "read_file", "args": {"path": "README.md"}}'
    tools = client._client.responses.calls[0]["tools"]
    assert tools == [
        {
            "type": "function",
            "name": "read_file",
            "description": "Read file",
            "parameters": {"type": "object"},
        }
    ]


def test_llm_client_wraps_responses_native_text_as_final() -> None:
    response = SimpleNamespace(output=[], output_text="done")
    client = make_client("responses", tool_calling_mode="native", tools=[], responses_response=response)

    result = client.respond("system prompt", "hello")

    assert result == '{"final": "done"}'


def test_llm_client_uses_chat_native_tool_calling() -> None:
    function = SimpleNamespace(name="search_text", arguments='{"query": "Agent"}')
    message = SimpleNamespace(content=None, tool_calls=[SimpleNamespace(function=function)])
    response = SimpleNamespace(choices=[SimpleNamespace(message=message)])
    client = make_client(
        "chat_completions",
        tool_calling_mode="native",
        tools=[{"name": "search_text", "description": "Search text", "parameters": {"type": "object"}}],
        chat_response=response,
    )

    result = client.respond("system prompt", "hello")

    assert result == '{"tool": "search_text", "args": {"query": "Agent"}}'
    tools = client._client.chat.completions.calls[0]["tools"]
    assert tools == [
        {
            "type": "function",
            "function": {"name": "search_text", "description": "Search text", "parameters": {"type": "object"}},
        }
    ]


def test_llm_client_accepts_legacy_chat_function_call() -> None:
    function_call = SimpleNamespace(name="read_file", arguments='{"path": "README.md"}')
    message = SimpleNamespace(content=None, tool_calls=None, function_call=function_call)
    response = SimpleNamespace(choices=[SimpleNamespace(message=message)])
    client = make_client(
        "chat_completions",
        tool_calling_mode="native",
        tools=[{"name": "read_file", "description": "Read file", "parameters": {"type": "object"}}],
        chat_response=response,
    )

    result = client.respond("system prompt", "hello")

    assert result == '{"tool": "read_file", "args": {"path": "README.md"}}'
