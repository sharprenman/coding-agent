# Coding Agent 仓库规则

- 保持 CLI 参数向后兼容。
- 新增 agent 能力时必须补测试。
- 不读取或修改 `.env`、`.git`、缓存目录和字节码文件。
- 命令执行必须继续使用白名单，不开放任意 shell。
- 默认验证命令使用 `python -m pytest`。

