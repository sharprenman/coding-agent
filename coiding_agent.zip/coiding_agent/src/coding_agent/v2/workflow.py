from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class AgentPhase(str, Enum):
    EXPLORE = "explore"
    PLAN = "plan"
    IMPLEMENT = "implement"
    VERIFY = "verify"
    REVIEW = "review"
    FINALIZE = "finalize"


PHASE_PERMISSIONS: dict[AgentPhase, set[str]] = {
    AgentPhase.EXPLORE: {"low"},
    AgentPhase.PLAN: {"low"},
    AgentPhase.IMPLEMENT: {"low", "medium"},
    AgentPhase.VERIFY: {"low", "high"},
    AgentPhase.REVIEW: {"low"},
    AgentPhase.FINALIZE: {"low"},
}


@dataclass
class StagedWorkflow:
    """确定性的多阶段工作流控制器。"""

    phase: AgentPhase = AgentPhase.EXPLORE

    def enter(self, phase: AgentPhase) -> None:
        self.phase = phase

    def permissions_for_tool(self, tool_name: str) -> set[str]:
        if tool_name in {"write_file", "apply_patch"}:
            return PHASE_PERMISSIONS[AgentPhase.IMPLEMENT]
        if tool_name == "run_command":
            return PHASE_PERMISSIONS[AgentPhase.VERIFY]
        return PHASE_PERMISSIONS[AgentPhase.EXPLORE]

    def phase_for_tool(self, tool_name: str) -> AgentPhase:
        if tool_name in {"write_file", "apply_patch"}:
            return AgentPhase.IMPLEMENT
        if tool_name == "run_command":
            return AgentPhase.VERIFY
        return AgentPhase.EXPLORE

