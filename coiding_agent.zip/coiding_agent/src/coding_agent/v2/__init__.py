"""Coding Agent V2 扩展能力包。"""

