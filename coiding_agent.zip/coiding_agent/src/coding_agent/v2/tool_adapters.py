from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Protocol

from coding_agent.tools import ToolRegistry, ToolResult


class ToolAdapter(Protocol):
    """工具适配器协议，便于在本地调用和 MCP 调用之间切换。"""

    def run(self, name: str, args: dict) -> ToolResult:
        ...


@dataclass
class DirectToolAdapter:
    """直接调用当前进程内的工具注册表。"""

    registry: ToolRegistry

    def run(self, name: str, args: dict) -> ToolResult:
        return self.registry.run(name, args)


@dataclass
class LocalMcpServer:
    """进程内 MCP 风格工具路由器，不开放网络端口。"""

    registry: ToolRegistry

    def handle(self, request: dict) -> dict:
        method = request.get("method")
        request_id = request.get("id")
        if method == "tools/list":
            return {"jsonrpc": "2.0", "id": request_id, "result": {"tools": self.registry.function_specs()}}
        if method == "tools/call":
            params = request.get("params", {})
            name = params.get("name")
            args = params.get("arguments", {})
            if not isinstance(name, str) or not isinstance(args, dict):
                return _error(request_id, "工具调用参数不合法")
            result = self.registry.run(name, args)
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "result": {"ok": result.ok, "content": result.content, "error": result.error},
            }
        return _error(request_id, f"不支持的方法: {method}")


@dataclass
class McpToolAdapter:
    """通过进程内 MCP 风格协议调用工具。"""

    server: LocalMcpServer

    def run(self, name: str, args: dict) -> ToolResult:
        response = self.server.handle(
            {
                "jsonrpc": "2.0",
                "id": "local-call",
                "method": "tools/call",
                "params": {"name": name, "arguments": args},
            }
        )
        if "error" in response:
            return ToolResult(False, "", json.dumps(response["error"], ensure_ascii=False))
        payload = response.get("result", {})
        return ToolResult(bool(payload.get("ok")), str(payload.get("content", "")), payload.get("error"))


def _error(request_id: object, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": request_id, "error": {"code": -32602, "message": message}}

