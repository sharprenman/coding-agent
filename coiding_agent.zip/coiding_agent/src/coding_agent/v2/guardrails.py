from __future__ import annotations

import shlex
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from coding_agent.tools.safety import is_sensitive_path, resolve_workspace_path


class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    BLOCKED = "blocked"


@dataclass(frozen=True)
class GuardrailDecision:
    """护栏检查结果。"""

    allowed: bool
    risk: RiskLevel
    reason: str


class GuardrailEngine:
    """统一处理输入、工具调用和最终输出的安全检查。"""

    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve()

    def check_input(self, task: str) -> GuardrailDecision:
        lowered = task.lower()
        blocked_terms = ("read .env", "show .env", "api key", "secret key", "rm -rf", "delete .git")
        if any(term in lowered for term in blocked_terms):
            return GuardrailDecision(False, RiskLevel.BLOCKED, "任务请求敏感信息或危险操作")
        return GuardrailDecision(True, RiskLevel.LOW, "任务通过输入护栏")

    def check_tool_call(self, tool_name: str, args: dict, permissions: set[str]) -> GuardrailDecision:
        risk = risk_for_tool(tool_name)
        if risk.value not in permissions and "*" not in permissions:
            return GuardrailDecision(False, RiskLevel.BLOCKED, f"当前阶段不允许调用工具: {tool_name}")

        path_error = self._check_paths(args)
        if path_error is not None:
            return path_error
        if tool_name == "run_command":
            return self._check_command(args.get("command"))
        return GuardrailDecision(True, risk, "工具调用通过护栏")

    def check_output(self, final: str) -> GuardrailDecision:
        if final.strip():
            return GuardrailDecision(True, RiskLevel.LOW, "最终输出通过护栏")
        return GuardrailDecision(False, RiskLevel.BLOCKED, "最终输出为空")

    def _check_paths(self, args: dict) -> GuardrailDecision | None:
        for key in ("path", "file", "target"):
            value = args.get(key)
            if not isinstance(value, str):
                continue
            try:
                path = resolve_workspace_path(self.workspace, value)
            except ValueError as exc:
                return GuardrailDecision(False, RiskLevel.BLOCKED, str(exc))
            if is_sensitive_path(path):
                return GuardrailDecision(False, RiskLevel.BLOCKED, f"拒绝访问敏感路径: {value}")
        return None

    def _check_command(self, command: object) -> GuardrailDecision:
        if not isinstance(command, str):
            return GuardrailDecision(False, RiskLevel.BLOCKED, "命令必须是字符串")
        try:
            parts = shlex.split(command)
        except ValueError as exc:
            return GuardrailDecision(False, RiskLevel.BLOCKED, f"命令格式错误: {exc}")
        if parts[:2] in (["git", "diff"], ["git", "status"]):
            return GuardrailDecision(True, RiskLevel.LOW, "只读命令通过护栏")
        return GuardrailDecision(True, RiskLevel.HIGH, "命令交给白名单沙箱继续校验")


def risk_for_tool(tool_name: str) -> RiskLevel:
    """根据工具名给出默认风险等级。"""
    if tool_name in {"list_files", "read_file", "search_text", "summarize_workspace", "search_code_chunks"}:
        return RiskLevel.LOW
    if tool_name in {"write_file", "apply_patch"}:
        return RiskLevel.MEDIUM
    if tool_name == "run_command":
        return RiskLevel.HIGH
    return RiskLevel.HIGH

