from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class PlanUpdateAction:
    """模型请求更新当前执行计划。"""

    steps: list[str]


@dataclass(frozen=True)
class AskUserAction:
    """模型发现信息不足时，请求用户补充输入。"""

    question: str


@dataclass(frozen=True)
class ReviewFindingAction:
    """模型在审查阶段输出的一条结构化问题。"""

    file: str
    message: str
    severity: str = "medium"
    line: int | None = None


STRUCTURED_ACTION_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "type": {
            "type": "string",
            "enum": ["final", "tool_call", "plan_update", "ask_user", "review_finding"],
        },
        "final": {"type": "string"},
        "tool": {"type": "string"},
        "args": {"type": "object", "additionalProperties": True},
        "steps": {"type": "array", "items": {"type": "string"}},
        "question": {"type": "string"},
        "file": {"type": "string"},
        "message": {"type": "string"},
        "severity": {"type": "string"},
        "line": {"type": "integer"},
    },
    "required": ["type"],
}

