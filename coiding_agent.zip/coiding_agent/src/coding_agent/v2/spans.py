from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class TraceSpan:
    """一次可观测性 span 事件。"""

    span_id: str
    parent_id: str | None
    name: str
    kind: str
    start_time: float
    end_time: float
    status: str
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_event(self) -> dict[str, Any]:
        return {
            "type": "span",
            "span_id": self.span_id,
            "parent_id": self.parent_id,
            "name": self.name,
            "kind": self.kind,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "status": self.status,
            "metadata": self.metadata,
        }


def make_span(name: str, kind: str, status: str = "ok", parent_id: str | None = None, metadata: dict[str, Any] | None = None) -> TraceSpan:
    """快速创建一个即时完成的 span。"""
    now = time.time()
    return TraceSpan(
        span_id=str(uuid.uuid4()),
        parent_id=parent_id,
        name=name,
        kind=kind,
        start_time=now,
        end_time=now,
        status=status,
        metadata=metadata or {},
    )
