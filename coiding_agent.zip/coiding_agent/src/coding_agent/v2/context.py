from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from coding_agent.planner import Plan
from coding_agent.tools.safety import is_sensitive_path


@dataclass(frozen=True)
class ContextSnapshot:
    """一次模型调用前整理好的上下文快照。"""

    task_brief: str
    repo_context: str
    relevant_files: list[str]
    constraints: list[str]
    allowed_tools: list[str]
    relevant_chunks: list[object] = field(default_factory=list)

    def to_prompt_text(self) -> str:
        payload = {
            "task_brief": self.task_brief,
            "repo_context": self.repo_context,
            "relevant_files": self.relevant_files,
            "constraints": self.constraints,
            "allowed_tools": self.allowed_tools,
            "relevant_chunks": [chunk.to_text() for chunk in self.relevant_chunks],
        }
        return "Context snapshot:\n" + json.dumps(payload, ensure_ascii=False)


@dataclass
class ContextEngine:
    """上下文工程入口，负责把仓库信息压缩成模型可消费的结构。"""

    workspace: Path
    max_chunks: int = 5

    def build(
        self,
        task: str,
        plan: Plan | None = None,
        history_summary: str | None = None,
        allowed_tools: list[str] | None = None,
    ) -> ContextSnapshot:
        from coding_agent.indexer import summarize_workspace
        from coding_agent.runtime.retrieval import CodeChunkIndex

        workspace = self.workspace.resolve()
        summary = summarize_workspace(workspace).to_text()
        rules = load_agents_rules(workspace)
        chunks = CodeChunkIndex.build(workspace).search(task, limit=self.max_chunks)
        constraints = []
        if rules:
            constraints.append(rules)
        if history_summary:
            constraints.append(history_summary)
        if plan is not None:
            constraints.append(plan.to_prompt_text())
        return ContextSnapshot(
            task_brief=task,
            repo_context=summary,
            relevant_files=sorted({chunk.path for chunk in chunks}),
            constraints=constraints,
            allowed_tools=allowed_tools or [],
            relevant_chunks=chunks,
        )


def load_agents_rules(workspace: Path) -> str:
    """读取仓库根目录的 AGENTS.md 规则。"""
    path = workspace.resolve() / "AGENTS.md"
    if not path.exists() or not path.is_file() or is_sensitive_path(path):
        return ""
    try:
        return f"AGENTS.md:\n{path.read_text(encoding='utf-8')}"
    except UnicodeDecodeError:
        return ""
