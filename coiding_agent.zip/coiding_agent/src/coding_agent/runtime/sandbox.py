from __future__ import annotations

import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path

from coding_agent.code_intelligence import SKIP_DIRS
from coding_agent.tools.safety import is_sensitive_path


MAX_COPY_BYTES = 500_000


@dataclass(frozen=True)
class SandboxResult:
    returncode: int
    stdout: str
    stderr: str


class SandboxRunner:
    """运行白名单命令，支持原工作区和临时目录两种模式。"""

    def run(self, parts: tuple[str, ...], workspace: Path, mode: str, timeout_seconds: int) -> SandboxResult:
        if mode == "workspace":
            return self._run_in_directory(parts, workspace, timeout_seconds)
        if mode == "temp":
            with tempfile.TemporaryDirectory(prefix="coding-agent-") as temp_dir:
                temp_workspace = Path(temp_dir)
                self._copy_workspace(workspace.resolve(), temp_workspace)
                return self._run_in_directory(parts, temp_workspace, timeout_seconds)
        raise ValueError(f"Unsupported command mode: {mode}")

    def _run_in_directory(self, parts: tuple[str, ...], cwd: Path, timeout_seconds: int) -> SandboxResult:
        process = subprocess.run(
            list(parts),
            cwd=cwd,
            text=True,
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
        )
        return SandboxResult(process.returncode, process.stdout, process.stderr)

    def _copy_workspace(self, source: Path, target: Path) -> None:
        for path in source.rglob("*"):
            rel_parts = path.relative_to(source).parts
            if any(part in SKIP_DIRS for part in rel_parts):
                continue
            if is_sensitive_path(path):
                continue
            target_path = target / Path(*rel_parts)
            if path.is_dir():
                target_path.mkdir(parents=True, exist_ok=True)
                continue
            if not path.is_file() or path.stat().st_size > MAX_COPY_BYTES:
                continue
            target_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target_path)
