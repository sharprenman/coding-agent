from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from coding_agent.code_intelligence import SKIP_DIRS
from coding_agent.tools.safety import is_sensitive_path, resolve_workspace_path


MAX_FILE_BYTES = 200_000
CHUNK_LINES = 40


@dataclass(frozen=True)
class CodeChunk:
    path: str
    start_line: int
    end_line: int
    text: str
    score: int = 0

    def to_text(self) -> str:
        clean = self.text.strip().replace("\n", "\\n")
        if len(clean) > 240:
            clean = clean[:240] + f"...({len(clean)} chars)"
        return f"{self.path}:{self.start_line}-{self.end_line}: score={self.score} {clean}"


@dataclass
class CodeChunkIndex:
    workspace: Path
    chunks: list[CodeChunk]

    @classmethod
    def build(cls, workspace: Path) -> CodeChunkIndex:
        workspace = workspace.resolve()
        chunks: list[CodeChunk] = []
        for path in _iter_text_files(workspace):
            rel = path.relative_to(workspace).as_posix()
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except UnicodeDecodeError:
                continue
            for index in range(0, len(lines), CHUNK_LINES):
                chunk_lines = lines[index : index + CHUNK_LINES]
                if not chunk_lines:
                    continue
                chunks.append(
                    CodeChunk(
                        path=rel,
                        start_line=index + 1,
                        end_line=index + len(chunk_lines),
                        text="\n".join(chunk_lines),
                    )
                )
        return cls(workspace=workspace, chunks=chunks)

    def search(self, query: str, path: str = ".", limit: int = 10) -> list[CodeChunk]:
        root = resolve_workspace_path(self.workspace, path)
        query_terms = [term.lower() for term in query.split() if term.strip()]
        if not query_terms:
            return []

        scored = []
        for chunk in self.chunks:
            chunk_path = resolve_workspace_path(self.workspace, chunk.path)
            try:
                chunk_path.relative_to(root)
            except ValueError:
                continue
            haystack = (chunk.path + "\n" + chunk.text).lower()
            score = sum(haystack.count(term) for term in query_terms)
            if score:
                scored.append(
                    CodeChunk(
                        path=chunk.path,
                        start_line=chunk.start_line,
                        end_line=chunk.end_line,
                        text=chunk.text,
                        score=score,
                    )
                )
        return sorted(scored, key=lambda item: (-item.score, item.path, item.start_line))[:limit]


def _iter_text_files(workspace: Path):
    for path in workspace.rglob("*"):
        if not path.is_file():
            continue
        if any(part in SKIP_DIRS for part in path.relative_to(workspace).parts):
            continue
        if is_sensitive_path(path):
            continue
        if path.stat().st_size > MAX_FILE_BYTES:
            continue
        if path.suffix.lower() not in {".py", ".md", ".txt", ".toml", ".yaml", ".yml", ".json"}:
            continue
        yield path
