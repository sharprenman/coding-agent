from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class SessionNotFoundError(RuntimeError):
    """请求恢复不存在的 session 时抛出。"""


@dataclass
class SessionStore:
    """SQLite session history，用于长期保存 agent 运行记录。"""

    path: Path

    def __post_init__(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def create_or_update_session(self, session_id: str, workspace: Path, task: str) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                insert into sessions(id, workspace, task, created_at, updated_at)
                values (?, ?, ?, datetime('now'), datetime('now'))
                on conflict(id) do update set
                    workspace = excluded.workspace,
                    task = excluded.task,
                    updated_at = datetime('now')
                """,
                (session_id, str(workspace), task),
            )

    def append_event(self, session_id: str, step: int, event_type: str, payload: dict[str, Any]) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                insert into events(session_id, step, type, payload_json, created_at)
                values (?, ?, ?, ?, datetime('now'))
                """,
                (session_id, step, event_type, json.dumps(payload, ensure_ascii=False, default=str)),
            )
            connection.execute("update sessions set updated_at = datetime('now') where id = ?", (session_id,))

    def set_final(self, session_id: str, final: str) -> None:
        with self._connect() as connection:
            connection.execute(
                "update sessions set final = ?, updated_at = datetime('now') where id = ?",
                (final, session_id),
            )

    def load_history_summary(self, session_id: str) -> str:
        with self._connect() as connection:
            session = connection.execute(
                "select id, workspace, task, final from sessions where id = ?",
                (session_id,),
            ).fetchone()
            if session is None:
                raise SessionNotFoundError(f"Session not found: {session_id}")
            events = connection.execute(
                """
                select step, type, payload_json
                from events
                where session_id = ?
                order by id
                limit 30
                """,
                (session_id,),
            ).fetchall()

        lines = [
            "Previous session summary:",
            f"session_id: {session['id']}",
            f"workspace: {session['workspace']}",
            f"task: {session['task']}",
        ]
        if session["final"]:
            lines.append(f"final: {session['final']}")
        lines.append("events:")
        for event in events:
            payload = json.loads(event["payload_json"])
            lines.append(f"- step={event['step']} type={event['type']} payload={payload}")
        return "\n".join(lines)

    def _init_db(self) -> None:
        with self._connect() as connection:
            connection.execute(
                """
                create table if not exists sessions(
                    id text primary key,
                    workspace text not null,
                    task text not null,
                    created_at text not null,
                    updated_at text not null,
                    final text
                )
                """
            )
            connection.execute(
                """
                create table if not exists events(
                    id integer primary key autoincrement,
                    session_id text not null,
                    step integer not null,
                    type text not null,
                    payload_json text not null,
                    created_at text not null,
                    foreign key(session_id) references sessions(id)
                )
                """
            )

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        return connection
