from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


DEFAULT_MODEL = "gpt-5.4-mini"
DEFAULT_API_MODE = "responses"
DEFAULT_TOOL_CALLING_MODE = "json"
SUPPORTED_API_MODES = {"responses", "chat_completions"}
SUPPORTED_TOOL_CALLING_MODES = {"json", "native", "structured"}


class ConfigError(RuntimeError):
    """运行配置缺失时抛出的错误，比如没有设置 OPENAI_API_KEY。"""


@dataclass(frozen=True)
class Config:
    api_key: str
    model: str = DEFAULT_MODEL
    base_url: str | None = None
    api_mode: str = DEFAULT_API_MODE
    tool_calling_mode: str = DEFAULT_TOOL_CALLING_MODE


def load_config() -> Config:
    """从环境变量读取配置。

    函数会先尝试读取当前工作目录下的 .env 文件。
    如果系统环境变量已经有同名配置，系统环境变量优先。

    目前支持四个配置：
    - OPENAI_API_KEY：必填，用来调用 OpenAI API。
    - OPENAI_MODEL：可选，不填时使用 DEFAULT_MODEL。
    - OPENAI_BASE_URL：可选，用来接入第三方 OpenAI-compatible 服务。
    - OPENAI_API_MODE：可选，支持 responses 或 chat_completions。
    - TOOL_CALLING_MODE：可选，支持 json 或 native。
    """
    load_dotenv_file(Path.cwd() / ".env")

    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise ConfigError("OPENAI_API_KEY is required. Set it before running coding-agent.")

    model = os.getenv("OPENAI_MODEL", DEFAULT_MODEL).strip() or DEFAULT_MODEL
    base_url = os.getenv("OPENAI_BASE_URL", "").strip() or None
    api_mode = os.getenv("OPENAI_API_MODE", DEFAULT_API_MODE).strip() or DEFAULT_API_MODE
    if api_mode not in SUPPORTED_API_MODES:
        supported = ", ".join(sorted(SUPPORTED_API_MODES))
        raise ConfigError(f"OPENAI_API_MODE must be one of: {supported}")
    tool_calling_mode = os.getenv("TOOL_CALLING_MODE", DEFAULT_TOOL_CALLING_MODE).strip() or DEFAULT_TOOL_CALLING_MODE
    if tool_calling_mode not in SUPPORTED_TOOL_CALLING_MODES:
        supported = ", ".join(sorted(SUPPORTED_TOOL_CALLING_MODES))
        raise ConfigError(f"TOOL_CALLING_MODE must be one of: {supported}")

    return Config(
        api_key=api_key,
        model=model,
        base_url=base_url,
        api_mode=api_mode,
        tool_calling_mode=tool_calling_mode,
    )


def load_dotenv_file(path: Path) -> None:
    """加载 .env 文件。

    python-dotenv 的 override=False 表示：
    如果 PowerShell 里已经设置了同名环境变量，就不要用 .env 覆盖它。
    """
    try:
        from dotenv import load_dotenv
    except ModuleNotFoundError as exc:
        raise ConfigError("python-dotenv is required. Install with: python -m pip install -r requirements.txt") from exc

    load_dotenv(dotenv_path=path, override=False)
