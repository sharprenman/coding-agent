from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Protocol

from coding_agent.planner import Plan


class PromptContext(Protocol):
    """可以被追加到模型输入中的上下文对象。"""

    def to_prompt_text(self) -> str:
        ...


@dataclass(frozen=True)
class Observation:
    """一次工具或协议错误的观察结果。"""

    step: int
    ok: bool
    content: str
    error: str | None

    def to_prompt_text(self) -> str:
        payload = {
            "step": self.step,
            "ok": self.ok,
            "content": self.content,
            "error": self.error,
        }
        return "Tool observation:\n" + json.dumps(payload, ensure_ascii=False)


@dataclass
class AgentMemory:
    """单次任务的内存记录。

    目前只保存在进程内，不做数据库持久化。
    """

    user_task: str
    history_summary: str | None = None
    plan: Plan | None = None
    context: PromptContext | None = None
    observations: list[Observation] = field(default_factory=list)   #field(defailt_factory) 确保每次创建实例时，observations属性的初始值为独立新建的空列表

    def set_plan(self, plan: Plan) -> None:
        self.plan = plan

    def set_context(self, context: PromptContext) -> None:
        self.context = context

    def add_observation(self, step: int, ok: bool, content: str, error: str | None) -> None:
        self.observations.append(Observation(step=step, ok=ok, content=content, error=error))

    def to_model_input(self) -> str:
        parts = [f"User task:\n{self.user_task}"]
        if self.history_summary:
            parts.append(self.history_summary)
        if self.plan is not None:
            parts.append(self.plan.to_prompt_text())
        if self.context is not None:
            parts.append(self.context.to_prompt_text())
        parts.extend(observation.to_prompt_text() for observation in self.observations)
        return "\n\n".join(parts)
