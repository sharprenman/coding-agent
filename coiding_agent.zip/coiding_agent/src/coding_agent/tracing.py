from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol

from coding_agent.planner import Plan
from coding_agent.schema import FinalAction, InvalidAction, ToolAction, parse_action
from coding_agent.tools import ToolResult


LONG_ARG_KEYS = {"content", "patch_text"}


class Tracer(Protocol):
    """Agent 执行过程追踪接口。"""

    def plan(self, plan: Plan) -> None:
        ...

    def model_response(self, step: int, raw: str) -> None:
        ...

    def final(self, step: int, final: str) -> None:
        ...

    def tool_request(self, step: int, tool_name: str, args: dict) -> None:
        ...

    def tool_result(self, step: int, result: ToolResult) -> None:
        ...


class NullTracer:
    """默认追踪器：什么都不输出，保持普通模式简洁。"""

    def plan(self, plan: Plan) -> None:
        pass

    def model_response(self, step: int, raw: str) -> None:
        pass

    def final(self, step: int, final: str) -> None:
        pass

    def tool_request(self, step: int, tool_name: str, args: dict) -> None:
        pass

    def tool_result(self, step: int, result: ToolResult) -> None:
        pass


@dataclass
class CompositeTracer:
    """把同一个追踪事件转发给多个 tracer。"""

    tracers: list[Tracer]

    def plan(self, plan: Plan) -> None:
        for tracer in self.tracers:
            tracer.plan(plan)

    def model_response(self, step: int, raw: str) -> None:
        for tracer in self.tracers:
            tracer.model_response(step, raw)

    def final(self, step: int, final: str) -> None:
        for tracer in self.tracers:
            tracer.final(step, final)

    def tool_request(self, step: int, tool_name: str, args: dict) -> None:
        for tracer in self.tracers:
            tracer.tool_request(step, tool_name, args)

    def tool_result(self, step: int, result: ToolResult) -> None:
        for tracer in self.tracers:
            tracer.tool_result(step, result)


class ConsoleTracer:
    """把 agent 执行过程打印到终端。"""

    def plan(self, plan: Plan) -> None:
        print("[plan]")
        for index, step in enumerate(plan.steps, start=1):
            print(f"  {index}. {step}")

    def model_response(self, step: int, raw: str) -> None:
        action = parse_action(raw)
        if isinstance(action, FinalAction):
            print(f"[step {step}] model response: final length={len(action.final)}")
        elif isinstance(action, ToolAction):
            print(f"[step {step}] model response: tool={action.tool} {_summarize_args(action.args)}")
        elif isinstance(action, InvalidAction):
            print(f"[step {step}] model response: invalid ({action.error})")

    def final(self, step: int, final: str) -> None:
        print(f"[step {step}] model returned final")

    def tool_request(self, step: int, tool_name: str, args: dict) -> None:
        print(f"[step {step}] model requested tool: {tool_name} {_summarize_args(args)}")

    def tool_result(self, step: int, result: ToolResult) -> None:
        status = "ok" if result.ok else "failed"
        detail = result.error or result.content or "no content"
        print(f"[step {step}] tool result: {status} {_summarize_text(detail)}")


@dataclass
class MemoryTracer:
    """测试用追踪器：把事件保存起来，方便断言。"""

    events: list[str] = field(default_factory=list)

    def plan(self, plan: Plan) -> None:
        self.events.append(f"plan:{plan.steps}")

    def model_response(self, step: int, raw: str) -> None:
        self.events.append(f"model_response:{step}:{raw}")

    def final(self, step: int, final: str) -> None:
        self.events.append(f"final:{step}:{final}")

    def tool_request(self, step: int, tool_name: str, args: dict) -> None:
        self.events.append(f"tool_request:{step}:{tool_name}:{args}")

    def tool_result(self, step: int, result: ToolResult) -> None:
        self.events.append(f"tool_result:{step}:{result.ok}:{result.error}")


def _summarize_args(args: dict) -> str:
    """把工具参数压缩成适合终端查看的摘要。"""
    if not args:
        return "args={}"

    parts = []
    for key, value in args.items():
        if isinstance(value, str):
            if key in LONG_ARG_KEYS:
                parts.append(f"{key}_length={len(value)}")
            else:
                parts.append(f"{key}={_summarize_text(value)}")
        else:
            parts.append(f"{key}={value!r}")
    return " ".join(parts)


def _summarize_text(value: str, limit: int = 80) -> str:
    """压缩单个字符串，避免 verbose 输出刷屏。"""
    clean = value.replace("\n", "\\n")
    if len(clean) <= limit:
        return clean
    return clean[:limit] + f"...({len(clean)} chars)"
