from __future__ import annotations

import ast
import re
import tomllib
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

from coding_agent.tools.safety import is_sensitive_path


SKIP_DIRS = {".git", ".idea", ".pytest_cache", "__pycache__", ".venv", "build", "dist"}


@dataclass(frozen=True)
class ImportInfo:
    path: str
    imports: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class TestMapping:
    test_path: str
    source_path: str | None


@dataclass(frozen=True)
class ProjectIntelligence:
    dependencies: list[str]
    imports: list[ImportInfo]
    test_mappings: list[TestMapping]
    source_roots: list[str]
    architecture_summary: list[str]

    def to_text(self) -> str:
        lines = ["dependencies:"]
        lines.extend(f"- {dependency}" for dependency in self.dependencies or ["(none)"])

        lines.append("source_roots:")
        lines.extend(f"- {root}" for root in self.source_roots or ["(none)"])

        lines.append("imports:")
        if not self.imports:
            lines.append("- (none)")
        for item in self.imports:
            imports = ", ".join(item.imports) if item.imports else "(none)"
            lines.append(f"- {item.path}: {imports}")

        lines.append("test_mappings:")
        if not self.test_mappings:
            lines.append("- (none)")
        for mapping in self.test_mappings:
            source = mapping.source_path or "(unknown)"
            lines.append(f"- {mapping.test_path} -> {source}")

        lines.append("architecture_summary:")
        lines.extend(f"- {item}" for item in self.architecture_summary or ["(none)"])
        return "\n".join(lines)


def analyze_project(workspace: Path, max_import_files: int = 30) -> ProjectIntelligence:
    """生成项目级静态代码理解摘要。"""
    workspace = workspace.resolve()
    python_files = sorted(_iter_python_files(workspace), key=lambda path: path.relative_to(workspace).as_posix())
    rel_python_files = [path.relative_to(workspace).as_posix() for path in python_files]

    dependencies = _read_dependencies(workspace)
    imports = [_parse_imports(path, path.relative_to(workspace).as_posix()) for path in python_files[:max_import_files]]
    source_roots = _detect_source_roots(workspace)
    test_mappings = _map_tests_to_sources(rel_python_files)
    architecture_summary = _build_architecture_summary(workspace, rel_python_files, dependencies, source_roots, test_mappings)

    return ProjectIntelligence(
        dependencies=dependencies,
        imports=imports,
        test_mappings=test_mappings,
        source_roots=source_roots,
        architecture_summary=architecture_summary,
    )


def _iter_python_files(workspace: Path):
    for path in workspace.rglob("*.py"):
        if any(part in SKIP_DIRS for part in path.relative_to(workspace).parts):
            continue
        if is_sensitive_path(path):
            continue
        yield path


def _parse_imports(path: Path, rel: str) -> ImportInfo:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError):
        return ImportInfo(path=rel)

    imports: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.add(node.module.split(".", 1)[0])

    return ImportInfo(path=rel, imports=sorted(imports))


def _read_dependencies(workspace: Path) -> list[str]:
    dependencies: set[str] = set()
    pyproject = workspace / "pyproject.toml"
    if pyproject.exists():
        try:
            data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        except (tomllib.TOMLDecodeError, UnicodeDecodeError):
            data = {}
        project = data.get("project", {})
        dependencies.update(_dependency_name(item) for item in project.get("dependencies", []))
        optional = project.get("optional-dependencies", {})
        for items in optional.values():
            dependencies.update(_dependency_name(item) for item in items)

    requirements = workspace / "requirements.txt"
    if requirements.exists():
        try:
            for line in requirements.read_text(encoding="utf-8").splitlines():
                clean = line.split("#", 1)[0].strip()
                if clean and not clean.startswith(("-", "http://", "https://")):
                    dependencies.add(_dependency_name(clean))
        except UnicodeDecodeError:
            pass

    return sorted(item for item in dependencies if item)


def _dependency_name(value: str) -> str:
    return re.split(r"\s*(?:==|>=|<=|~=|!=|>|<|\[)", value.strip(), maxsplit=1)[0].strip()


def _detect_source_roots(workspace: Path) -> list[str]:
    roots: set[str] = set()
    if (workspace / "src").is_dir():
        roots.add("src")

    for init_file in workspace.rglob("__init__.py"):
        if any(part in SKIP_DIRS for part in init_file.relative_to(workspace).parts):
            continue
        parent = init_file.parent.relative_to(workspace).as_posix()
        if parent and not parent.startswith("tests"):
            roots.add(parent)

    return sorted(roots)


def _map_tests_to_sources(rel_python_files: list[str]) -> list[TestMapping]:
    source_files = [path for path in rel_python_files if not _is_test_path(path)]
    by_stem: dict[str, list[str]] = defaultdict(list)
    for source in source_files:
        by_stem[Path(source).stem].append(source)

    mappings: list[TestMapping] = []
    for test_path in rel_python_files:
        if not _is_test_path(test_path):
            continue
        stem = Path(test_path).stem
        source_stem = stem.removeprefix("test_")
        if source_stem == stem and stem.endswith("_test"):
            source_stem = stem[: -len("_test")]
        candidates = sorted(by_stem.get(source_stem, []))
        mappings.append(TestMapping(test_path=test_path, source_path=candidates[0] if candidates else None))
    return mappings


def _is_test_path(path: str) -> bool:
    parts = Path(path).parts
    name = Path(path).name
    return "tests" in parts or name.startswith("test_") or name.endswith("_test.py")


def _build_architecture_summary(
    workspace: Path,
    rel_python_files: list[str],
    dependencies: list[str],
    source_roots: list[str],
    test_mappings: list[TestMapping],
) -> list[str]:
    summary: list[str] = []
    if (workspace / "pyproject.toml").exists():
        summary.append("Python project configured with pyproject.toml.")
    if (workspace / "requirements.txt").exists():
        summary.append("Dependencies are also listed in requirements.txt.")
    if source_roots:
        summary.append("Source code is organized under: " + ", ".join(source_roots) + ".")
    if any(_is_test_path(path) for path in rel_python_files):
        summary.append(f"Test suite detected with {len(test_mappings)} mapped test file(s).")
    if dependencies:
        summary.append("External dependencies detected: " + ", ".join(dependencies[:8]) + ".")
    if any(path.endswith(("main.py", "__main__.py")) for path in rel_python_files):
        summary.append("Entrypoint-style Python modules are present.")
    return summary
