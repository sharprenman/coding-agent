from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from coding_agent.planner import Plan
from coding_agent.tools import ToolResult
from coding_agent.v2.spans import make_span


@dataclass
class JsonlAuditTracer:
    """把 agent 执行事件写入 JSONL 审计日志。"""

    path: Path

    def __post_init__(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("", encoding="utf-8")

    def plan(self, plan: Plan) -> None:
        self._write({"type": "plan", "steps": plan.steps})

    def model_response(self, step: int, raw: str) -> None:
        self._write({"type": "model_response", "step": step, "content": raw})

    def final(self, step: int, final: str) -> None:
        self._write({"type": "final", "step": step, "content": final})

    def tool_request(self, step: int, tool_name: str, args: dict) -> None:
        self._write({"type": "tool_call", "step": step, "tool": tool_name, "args": args})

    def tool_result(self, step: int, result: ToolResult) -> None:
        self._write(
            {
                "type": "tool_result",
                "step": step,
                "ok": result.ok,
                "content": result.content,
                "error": result.error,
            }
        )

    def _write(self, event: dict[str, Any]) -> None:
        with self.path.open("a", encoding="utf-8") as file:
            file.write(json.dumps(event, ensure_ascii=False, default=str))
            file.write("\n")


@dataclass
class JsonlSpanTracer:
    """把 agent 执行过程写成 span 风格 JSONL。"""

    path: Path

    def __post_init__(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("", encoding="utf-8")

    def plan(self, plan: Plan) -> None:
        self._write(make_span("plan", "phase", metadata={"steps": plan.steps}).to_event())

    def model_response(self, step: int, raw: str) -> None:
        self._write(make_span("llm_call", "llm_call", metadata={"step": step, "content": raw}).to_event())

    def final(self, step: int, final: str) -> None:
        self._write(make_span("finalize", "phase", metadata={"step": step, "content": final}).to_event())

    def tool_request(self, step: int, tool_name: str, args: dict) -> None:
        self._write(make_span("tool_call", "tool_call", metadata={"step": step, "tool": tool_name, "args": args}).to_event())

    def tool_result(self, step: int, result: ToolResult) -> None:
        status = "ok" if result.ok else "error"
        self._write(
            make_span(
                "tool_result",
                "tool_call",
                status=status,
                metadata={"step": step, "ok": result.ok, "content": result.content, "error": result.error},
            ).to_event()
        )

    def _write(self, event: dict[str, Any]) -> None:
        with self.path.open("a", encoding="utf-8") as file:
            file.write(json.dumps(event, ensure_ascii=False, default=str))
            file.write("\n")
