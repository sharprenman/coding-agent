from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import TypeAlias

from coding_agent.v2.actions import AskUserAction, PlanUpdateAction, ReviewFindingAction


@dataclass(frozen=True)
class FinalAction:
    """模型已经完成任务，准备返回最终答案。"""

    final: str


@dataclass(frozen=True)
class ToolAction:
    """模型请求 agent 执行一个工具。"""

    tool: str
    args: dict


@dataclass(frozen=True)
class InvalidAction:
    """模型输出不符合协议。

    这里不直接抛异常，而是把错误交给 agent loop。
    agent 可以把错误反馈给模型，让模型下一轮修正。
    """

    error: str
    raw: str


Action: TypeAlias = FinalAction | ToolAction | PlanUpdateAction | AskUserAction | ReviewFindingAction | InvalidAction


def parse_action(raw: str) -> Action:
    """把模型原始输出解析成结构化 Action。"""
    raw = raw.strip()
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        extracted = extract_json_object(raw)
        if extracted is None:
            return InvalidAction(error=f"Invalid JSON: {exc.msg}", raw=raw)
        try:
            value = json.loads(extracted)
        except json.JSONDecodeError as extracted_exc:
            return InvalidAction(error=f"Invalid JSON: {extracted_exc.msg}", raw=raw)

    if not isinstance(value, dict):
        return InvalidAction(error="Action must be a JSON object", raw=raw)

    if "type" in value:
        return parse_structured_action(value, raw)

    has_final = "final" in value
    has_tool = "tool" in value
    if has_final and has_tool:
        return InvalidAction(error="Action cannot contain both final and tool", raw=raw)
    if not has_final and not has_tool:
        return InvalidAction(error="Action must contain final or tool", raw=raw)

    if has_final:
        final = value["final"]
        if not isinstance(final, str):
            return InvalidAction(error="final must be a string", raw=raw)
        return FinalAction(final=final)

    tool = value["tool"]
    args = value.get("args", {})
    if not isinstance(tool, str):
        return InvalidAction(error="tool must be a string", raw=raw)
    if not isinstance(args, dict):
        return InvalidAction(error="args must be an object", raw=raw)

    return ToolAction(tool=tool, args=args)


def parse_structured_action(value: dict, raw: str) -> Action:
    """解析 V2 的显式类型动作协议。"""
    action_type = value.get("type")
    if not isinstance(action_type, str):
        return InvalidAction(error="type must be a string", raw=raw)
    if action_type == "final":
        final = value.get("final")
        if not isinstance(final, str):
            return InvalidAction(error="final must be a string", raw=raw)
        return FinalAction(final=final)
    if action_type == "tool_call":
        tool = value.get("tool")
        args = value.get("args", {})
        if not isinstance(tool, str):
            return InvalidAction(error="tool must be a string", raw=raw)
        if not isinstance(args, dict):
            return InvalidAction(error="args must be an object", raw=raw)
        return ToolAction(tool=tool, args=args)
    if action_type == "plan_update":
        steps = value.get("steps")
        if not isinstance(steps, list) or not all(isinstance(step, str) for step in steps):
            return InvalidAction(error="steps must be an array of strings", raw=raw)
        return PlanUpdateAction(steps=steps)
    if action_type == "ask_user":
        question = value.get("question")
        if not isinstance(question, str):
            return InvalidAction(error="question must be a string", raw=raw)
        return AskUserAction(question=question)
    if action_type == "review_finding":
        file = value.get("file")
        message = value.get("message")
        severity = value.get("severity", "medium")
        line = value.get("line")
        if not isinstance(file, str):
            return InvalidAction(error="file must be a string", raw=raw)
        if not isinstance(message, str):
            return InvalidAction(error="message must be a string", raw=raw)
        if not isinstance(severity, str):
            return InvalidAction(error="severity must be a string", raw=raw)
        if line is not None and not isinstance(line, int):
            return InvalidAction(error="line must be an integer", raw=raw)
        return ReviewFindingAction(file=file, message=message, severity=severity, line=line)
    return InvalidAction(error=f"Unknown action type: {action_type}", raw=raw)


def extract_json_object(raw: str) -> str | None:
    """从模型输出中提取第一个 JSON 对象。

    兼容两种常见错误：
    - 模型返回 ```json ... ``` Markdown 代码块。
    - 模型在 JSON 前后加了说明文本。
    """
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw, flags=re.DOTALL | re.IGNORECASE)
    if fenced:
        return fenced.group(1).strip()

    start = raw.find("{")
    if start == -1:
        return None

    depth = 0
    in_string = False
    escaped = False
    for index in range(start, len(raw)):
        char = raw[index]
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char == '"':
            in_string = not in_string
            continue
        if in_string:
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return raw[start : index + 1]

    return None
