from __future__ import annotations

from dataclasses import dataclass

from coding_agent.schema import ToolAction
from coding_agent.tools import ToolRegistry, ToolResult
from coding_agent.tracing import Tracer
from coding_agent.v2.guardrails import GuardrailEngine
from coding_agent.v2.tool_adapters import DirectToolAdapter, ToolAdapter
from coding_agent.v2.workflow import StagedWorkflow


@dataclass
class Executor:
    """执行 ToolAction 的小模块。

    Agent 负责决定下一步是什么；Executor 只负责执行工具并记录 trace。
    """

    tools: ToolRegistry
    tracer: Tracer
    guardrails: GuardrailEngine | None = None
    workflow: StagedWorkflow | None = None
    adapter: ToolAdapter | None = None

    def execute(self, step: int, action: ToolAction) -> ToolResult:
        self.tracer.tool_request(step, action.tool, action.args)
        if self.guardrails is not None:
            permissions = self.workflow.permissions_for_tool(action.tool) if self.workflow is not None else {"low", "medium", "high"}
            decision = self.guardrails.check_tool_call(action.tool, action.args, permissions)
            if not decision.allowed:
                result = ToolResult(False, "", decision.reason)
                self.tracer.tool_result(step, result)
                return result
        adapter = self.adapter or DirectToolAdapter(self.tools)
        result = adapter.run(action.tool, action.args)
        self.tracer.tool_result(step, result)
        return result
