from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol


@dataclass(frozen=True)
class Plan:
    """一次任务的短计划。"""

    steps: list[str]

    def to_prompt_text(self) -> str:
        lines = [f"{index}. {step}" for index, step in enumerate(self.steps, start=1)]
        return "Plan:\n" + "\n".join(lines)


class Planner(Protocol):
    """Planner 接口。

    目前使用本地规则生成计划，后续可以替换成 LLM planner。
    """

    def plan(self, task: str) -> Plan:
        ...


class SimplePlanner:
    """轻量本地 planner。

    目的不是生成完美计划，而是让 agent loop 有明确的执行意图。
    """

    def plan(self, task: str) -> Plan:
        lowered = task.lower()
        steps = ["理解用户任务和当前限制"]

        if any(keyword in lowered for keyword in ["文件", "file", "python", "代码", "创建", "写", "修改", "readme", ".py"]):
            steps.append("必要时查看或修改工作区文件")
        if any(keyword in lowered for keyword in ["测试", "test", "运行", "pytest"]):
            steps.append("必要时运行允许的验证命令")

        steps.append("完成任务后返回简洁最终结果")
        return Plan(steps=steps)
