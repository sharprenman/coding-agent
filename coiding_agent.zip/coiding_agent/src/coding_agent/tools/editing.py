from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

from coding_agent.tools.base import ToolResult
from coding_agent.tools.safety import is_sensitive_path, resolve_workspace_path, truncate
from coding_agent.tools.schema import ToolArg, ToolArgsSchema


@dataclass
class WriteFileTool:
    """写入工作区内的 UTF-8 文本文件。

    这个工具适合创建简单文件。复杂代码修改仍建议使用 apply_patch。
    """

    workspace: Path
    auto_yes: bool = False
    name: str = "write_file"
    description: str = (
        "Create or overwrite a workspace-relative UTF-8 text file. "
        "Args: {'path': string, 'content': string}. Requires confirmation unless --yes is set."
    )
    args_schema: ToolArgsSchema = ToolArgsSchema(
        args=(
            ToolArg(
                name="path",
                type="string",
                description="Workspace-relative file path to create or overwrite.",
                required=True,
            ),
            ToolArg(name="content", type="string", description="Complete UTF-8 text content to write.", required=True),
        )
    )

    def run(self, args: dict) -> ToolResult:
        raw_path = args.get("path")
        content = args.get("content")
        if not raw_path:
            return ToolResult(False, "", "Missing required arg: path")
        if not isinstance(content, str):
            return ToolResult(False, "", "Missing required string arg: content")

        try:
            path = resolve_workspace_path(self.workspace, raw_path)
            if is_sensitive_path(path):
                return ToolResult(False, "", f"Refusing to write sensitive path: {raw_path}")
            if path.exists() and path.is_dir():
                return ToolResult(False, "", f"Path is a directory: {raw_path}")

            if not self.auto_yes:
                action = "overwrite" if path.exists() else "create"
                answer = input(f"\n{action} {raw_path}? [y/N] ").strip().lower()
                if answer not in {"y", "yes"}:
                    return ToolResult(False, "", "User declined file write")

            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            rel = path.relative_to(self.workspace.resolve())
            return ToolResult(True, f"Wrote {rel}")
        except Exception as exc:
            return ToolResult(False, "", str(exc))


@dataclass
class ApplyPatchTool:
    """应用 unified diff patch 的编辑工具。

    默认会向用户确认，只有传入 --yes 时才自动应用。
    这样可以防止模型在没有确认的情况下直接改文件。
    """

    workspace: Path
    auto_yes: bool = False
    name: str = "apply_patch"
    description: str = "Apply a unified diff patch. Args: {'patch_text': string}. Requires confirmation unless --yes is set."
    args_schema: ToolArgsSchema = ToolArgsSchema(
        args=(
            ToolArg(name="patch_text", type="string", description="Unified diff patch text to apply.", required=True),
        )
    )

    def run(self, args: dict) -> ToolResult:
        patch_text = args.get("patch_text")
        if not patch_text:
            return ToolResult(False, "", "Missing required arg: patch_text")
        # 这里只做最基础的格式检查，真正能不能应用交给 git apply 判断。
        if "+++" not in patch_text or "---" not in patch_text:
            return ToolResult(False, "", "patch_text must be a unified diff")

        target_error = self._validate_patch_targets(patch_text)
        if target_error is not None:
            return ToolResult(False, "", target_error)

        if not self.auto_yes:
            # 交互确认是第一版最重要的安全措施。
            targets = ", ".join(extract_patch_targets(patch_text)) or "unknown files"
            print("\nProposed patch:\n")
            print(f"Targets: {targets}\n")
            print(truncate(patch_text))
            answer = input("\nApply this patch? [y/N] ").strip().lower()
            if answer not in {"y", "yes"}:
                return ToolResult(False, "", "User declined patch")

        try:
            process = subprocess.run(
                ["git", "apply", "--whitespace=nowarn", "-"],
                input=patch_text,
                cwd=self.workspace,
                text=True,
                capture_output=True,
                timeout=30,
                check=False,
            )
            if process.returncode != 0:
                return ToolResult(False, truncate(process.stdout), truncate(process.stderr or "git apply failed"))

            # 应用成功后，把当前 diff 返回给模型，方便它总结改了什么。
            diff = subprocess.run(
                ["git", "diff", "--", "."],
                cwd=self.workspace,
                text=True,
                capture_output=True,
                timeout=30,
                check=False,
            )
            return ToolResult(True, truncate(diff.stdout or "Patch applied."))
        except FileNotFoundError:
            return ToolResult(False, "", "git is required to apply patches")
        except subprocess.TimeoutExpired:
            return ToolResult(False, "", "Patch command timed out")

    def _validate_patch_targets(self, patch_text: str) -> str | None:
        targets = extract_patch_targets(patch_text)
        if not targets:
            return "Patch does not include a workspace target file"

        for target in targets:
            try:
                path = resolve_workspace_path(self.workspace, target)
            except ValueError as exc:
                return str(exc)
            if is_sensitive_path(path):
                return f"Refusing to patch sensitive path: {target}"
        return None


def extract_patch_targets(patch_text: str) -> list[str]:
    """从 unified diff 中提取会被修改的目标路径。"""
    targets: list[str] = []
    for line in patch_text.splitlines():
        if not line.startswith("+++ "):
            continue
        raw = line[4:].strip()
        if raw == "/dev/null":
            continue
        if raw.startswith("b/") or raw.startswith("a/"):
            raw = raw[2:]
        # git diff 可能在路径后附带 tab 分隔的元信息。
        raw = raw.split("\t", 1)[0]
        if raw and raw not in targets:
            targets.append(raw)
    return targets
