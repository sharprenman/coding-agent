from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from coding_agent.runtime.retrieval import CodeChunkIndex
from coding_agent.tools.base import ToolResult
from coding_agent.tools.safety import truncate
from coding_agent.tools.schema import ToolArg, ToolArgsSchema


@dataclass
class SearchCodeChunksTool:
    """在本地代码 chunk 中检索相关片段。"""

    workspace: Path
    name: str = "search_code_chunks"
    description: str = "Search local code chunks by keyword, path, and symbol text. Args: {'query': string, 'path': optional string, 'limit': optional integer}."
    args_schema: ToolArgsSchema = ToolArgsSchema(
        args=(
            ToolArg(name="query", type="string", description="Search query.", required=True),
            ToolArg(name="path", type="string", description="Optional workspace-relative path to search under."),
            ToolArg(name="limit", type="integer", description="Maximum number of chunks to return."),
        )
    )

    def run(self, args: dict) -> ToolResult:
        query = args.get("query")
        path = args.get("path", ".")
        limit = args.get("limit", 10)
        try:
            chunks = CodeChunkIndex.build(self.workspace).search(query=query, path=path, limit=limit)
            content = "\n".join(chunk.to_text() for chunk in chunks) or "No matching chunks."
            return ToolResult(True, truncate(content))
        except Exception as exc:
            return ToolResult(False, "", str(exc))
