from __future__ import annotations

from pathlib import Path

from coding_agent.tools.base import ToolRegistry
from coding_agent.tools.commands import RunCommandTool
from coding_agent.tools.editing import ApplyPatchTool, WriteFileTool
from coding_agent.tools.indexing import SummarizeWorkspaceTool
from coding_agent.tools.readonly import ListFilesTool, ReadFileTool, SearchTextTool
from coding_agent.tools.retrieval import SearchCodeChunksTool


def build_default_tools(workspace: Path, auto_yes: bool, command_mode: str = "workspace") -> ToolRegistry:
    """创建默认工具集合。"""
    registry = ToolRegistry()
    registry.register(ListFilesTool(workspace))
    registry.register(ReadFileTool(workspace))
    registry.register(SearchTextTool(workspace))
    registry.register(SummarizeWorkspaceTool(workspace))
    registry.register(SearchCodeChunksTool(workspace))
    registry.register(WriteFileTool(workspace, auto_yes=auto_yes))
    registry.register(ApplyPatchTool(workspace, auto_yes=auto_yes))
    registry.register(RunCommandTool(workspace, command_mode=command_mode))
    return registry


def build_review_tools(workspace: Path) -> ToolRegistry:
    """创建 Review Mode 使用的只读工具集合。"""
    registry = ToolRegistry()
    registry.register(ListFilesTool(workspace))
    registry.register(ReadFileTool(workspace))
    registry.register(SearchTextTool(workspace))
    registry.register(SummarizeWorkspaceTool(workspace))
    registry.register(SearchCodeChunksTool(workspace))
    return registry
