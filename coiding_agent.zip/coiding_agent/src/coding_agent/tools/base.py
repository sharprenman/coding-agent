from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Protocol

from coding_agent.tools.schema import ToolArgsSchema


DEFAULT_TOOL_PARAMETERS = {
    "type": "object",
    "properties": {},
    "additionalProperties": True,
}


@dataclass(frozen=True)
class ToolResult:
    """工具执行结果。

    ok 表示工具是否成功；content 是给模型看的结果；
    error 是失败原因，方便模型下一轮修正。
    """

    ok: bool
    content: str
    error: str | None = None


class Tool(Protocol):
    """所有工具都要遵守的接口。"""

    name: str
    description: str
    args_schema: ToolArgsSchema

    def run(self, args: dict) -> ToolResult:
        ...


class ToolRegistry:
    """工具注册表。

    Agent 不直接认识每个工具，只通过工具名在这里查找并执行。
    后续新增工具时，只需要 register 进去。
    """

    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def descriptions(self) -> str:
        """生成工具说明，放进 system prompt 里告诉模型可以用哪些工具。"""
        lines = []
        for tool in self._tools.values():
            lines.append(f"- {tool.name}: {tool.description}")
        return "\n".join(lines)

    def function_specs(self) -> list[dict]:
        """生成原生 tool calling 可用的函数定义。"""
        specs = []
        for tool in self._tools.values():
            specs.append(
                {
                    "name": tool.name,
                    "description": tool.description,
                    "parameters": deepcopy(_tool_parameters(tool)),
                }
            )
        return specs

    def names(self) -> list[str]:
        """返回当前已注册的工具名称。"""
        return list(self._tools)

    def run(self, name: str, args: dict) -> ToolResult:
        """按名称执行工具；如果模型请求了不存在的工具，就返回错误给模型。"""
        tool = self._tools.get(name)
        if tool is None:
            return ToolResult(ok=False, content="", error=f"Unknown tool: {name}")
        schema = getattr(tool, "args_schema", None)
        if schema is not None:
            error = schema.validate(args)
            if error is not None:
                return ToolResult(ok=False, content="", error=error)
        return tool.run(args)


def _tool_parameters(tool: Tool) -> dict:
    schema = getattr(tool, "args_schema", None)
    if schema is not None:
        return schema.to_json_schema()
    return getattr(tool, "parameters", DEFAULT_TOOL_PARAMETERS)
