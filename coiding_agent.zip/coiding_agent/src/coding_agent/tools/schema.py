from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal


JsonType = Literal["string", "integer", "number", "boolean", "object", "array"]


@dataclass(frozen=True)
class ToolArg:
    """单个工具参数的 schema 描述。"""

    name: str
    type: JsonType
    description: str
    required: bool = False

    def to_json_schema(self) -> dict[str, Any]:
        return {"type": self.type, "description": self.description}


@dataclass(frozen=True)
class ToolArgsSchema:
    """工具参数 schema，用于校验参数并生成原生 tool calling schema。"""

    args: tuple[ToolArg, ...]
    allow_extra: bool = False

    def to_json_schema(self) -> dict[str, Any]:
        schema: dict[str, Any] = {
            "type": "object",
            "properties": {arg.name: arg.to_json_schema() for arg in self.args},
            "additionalProperties": self.allow_extra,
        }
        required = [arg.name for arg in self.args if arg.required]
        if required:
            schema["required"] = required
        return schema

    def validate(self, value: dict) -> str | None:
        known_args = {arg.name: arg for arg in self.args}
        for arg in self.args:
            if arg.required and arg.name not in value:
                return f"Missing required arg: {arg.name}"

        if not self.allow_extra:
            extra = sorted(key for key in value if key not in known_args)
            if extra:
                return f"Unexpected arg: {extra[0]}"

        for name, raw_value in value.items():
            arg = known_args.get(name)
            if arg is None:
                continue
            if not _matches_type(raw_value, arg.type):
                return f"Arg {name} must be {arg.type}"
        return None


EMPTY_ARGS_SCHEMA = ToolArgsSchema(args=())


def _matches_type(value: object, expected: JsonType) -> bool:
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return (isinstance(value, int | float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    return False
