from __future__ import annotations

from pathlib import Path


SENSITIVE_NAMES = {".env", ".env.local", ".envrc"}
SENSITIVE_PARTS = {"id_rsa", "id_ed25519", "credentials", "secret", "secrets", "token"}
SENSITIVE_DIRS = {".git"}


def truncate(text: str, limit: int = 12000) -> str:
    """截断过长输出，避免一次工具结果把上下文撑爆。"""
    if len(text) <= limit:
        return text
    return text[:limit] + f"\n...[truncated {len(text) - limit} characters]"


def resolve_workspace_path(workspace: Path, user_path: str | None) -> Path:
    """把用户传入的相对路径解析到 workspace 内。

    这是安全边界：如果路径使用 ../ 逃出工作区，就直接拒绝。
    """
    raw = user_path or "."
    candidate = (workspace / raw).resolve()
    workspace_resolved = workspace.resolve()

    try:
        candidate.relative_to(workspace_resolved)
    except ValueError as exc:
        raise ValueError(f"Path escapes workspace: {raw}") from exc

    return candidate


def is_sensitive_path(path: Path) -> bool:
    """判断路径是否像密钥、token、环境变量文件等敏感文件。"""
    lowered_parts = [part.lower() for part in path.parts]
    if path.name.lower() in SENSITIVE_NAMES:
        return True
    if any(part in SENSITIVE_DIRS for part in lowered_parts):
        return True
    return any(marker in part for part in lowered_parts for marker in SENSITIVE_PARTS)
