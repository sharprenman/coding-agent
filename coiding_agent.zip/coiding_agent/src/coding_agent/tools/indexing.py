from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from coding_agent.indexer import summarize_workspace
from coding_agent.tools.base import ToolResult
from coding_agent.tools.safety import truncate
from coding_agent.tools.schema import EMPTY_ARGS_SCHEMA, ToolArgsSchema


@dataclass
class SummarizeWorkspaceTool:
    """生成工作区轻量代码索引。"""

    workspace: Path
    name: str = "summarize_workspace"
    description: str = (
        "Summarize workspace files, key files, entrypoints, Python symbols, imports, dependencies, "
        "test mappings, and architecture hints. Args: {}."
    )
    args_schema: ToolArgsSchema = EMPTY_ARGS_SCHEMA

    def run(self, args: dict) -> ToolResult:
        try:
            summary = summarize_workspace(self.workspace)
            return ToolResult(True, truncate(summary.to_text()))
        except Exception as exc:
            return ToolResult(False, "", str(exc))
