from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from coding_agent.tools.base import ToolResult
from coding_agent.tools.safety import is_sensitive_path, resolve_workspace_path, truncate
from coding_agent.tools.schema import ToolArg, ToolArgsSchema


@dataclass
class ListFilesTool:
    """列出工作区内的文件和目录，只读，不会修改任何东西。"""

    workspace: Path
    name: str = "list_files"
    description: str = "List files under a workspace-relative directory. Args: {'path': optional string}."
    args_schema: ToolArgsSchema = ToolArgsSchema(
        args=(
            ToolArg(
                name="path",
                type="string",
                description="Workspace-relative directory path. Defaults to current directory.",
            ),
        )
    )

    def run(self, args: dict) -> ToolResult:
        try:
            # 所有路径都必须先通过 workspace 安全检查。
            path = resolve_workspace_path(self.workspace, args.get("path", "."))
            if not path.exists():
                return ToolResult(False, "", f"Path does not exist: {args.get('path', '.')}")
            if not path.is_dir():
                return ToolResult(False, "", f"Path is not a directory: {args.get('path', '.')}")

            entries = []
            for child in sorted(path.iterdir(), key=lambda item: (not item.is_dir(), item.name.lower())):
                # 不把 .env、secret、token 等敏感路径暴露给模型。
                if is_sensitive_path(child):
                    continue
                suffix = "/" if child.is_dir() else ""
                entries.append(f"{child.relative_to(self.workspace.resolve())}{suffix}")
            return ToolResult(True, truncate("\n".join(entries) or "(empty)"))
        except Exception as exc:
            return ToolResult(False, "", str(exc))


@dataclass
class ReadFileTool:
    """读取工作区内的 UTF-8 文本文件。"""

    workspace: Path
    name: str = "read_file"
    description: str = "Read a workspace-relative text file. Args: {'path': string}."
    args_schema: ToolArgsSchema = ToolArgsSchema(
        args=(
            ToolArg(
                name="path",
                type="string",
                description="Workspace-relative text file path.",
                required=True,
            ),
        )
    )

    def run(self, args: dict) -> ToolResult:
        try:
            raw_path = args.get("path")
            if not raw_path:
                return ToolResult(False, "", "Missing required arg: path")
            path = resolve_workspace_path(self.workspace, raw_path)
            # 即使文件在 workspace 内，也不能读取敏感文件。
            if is_sensitive_path(path):
                return ToolResult(False, "", f"Refusing to read sensitive path: {raw_path}")
            if not path.exists():
                return ToolResult(False, "", f"File does not exist: {raw_path}")
            if not path.is_file():
                return ToolResult(False, "", f"Path is not a file: {raw_path}")
            return ToolResult(True, truncate(path.read_text(encoding="utf-8")))
        except UnicodeDecodeError:
            return ToolResult(False, "", "File is not valid UTF-8 text")
        except Exception as exc:
            return ToolResult(False, "", str(exc))


@dataclass
class SearchTextTool:
    """在工作区文本文件中搜索关键词。"""

    workspace: Path
    name: str = "search_text"
    description: str = "Search text in workspace files. Args: {'query': string, 'path': optional string}."
    args_schema: ToolArgsSchema = ToolArgsSchema(
        args=(
            ToolArg(name="query", type="string", description="Text to search for.", required=True),
            ToolArg(name="path", type="string", description="Optional workspace-relative file or directory path."),
        )
    )

    def run(self, args: dict) -> ToolResult:
        try:
            query = args.get("query")
            if not query:
                return ToolResult(False, "", "Missing required arg: query")

            root = resolve_workspace_path(self.workspace, args.get("path", "."))
            if not root.exists():
                return ToolResult(False, "", f"Path does not exist: {args.get('path', '.')}")

            files = [root] if root.is_file() else [p for p in root.rglob("*") if p.is_file()]
            matches = []
            for file_path in files:
                if is_sensitive_path(file_path):
                    continue
                try:
                    text = file_path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    # 二进制文件或非 UTF-8 文件先跳过，避免搜索工具报错中断。
                    continue
                for line_number, line in enumerate(text.splitlines(), start=1):
                    if query in line:
                        rel = file_path.relative_to(self.workspace.resolve())
                        matches.append(f"{rel}:{line_number}: {line.strip()}")
                        if len(matches) >= 100:
                            return ToolResult(True, truncate("\n".join(matches)))

            return ToolResult(True, truncate("\n".join(matches) or "No matches."))
        except Exception as exc:
            return ToolResult(False, "", str(exc))
