from __future__ import annotations

import shlex
from dataclasses import dataclass
from pathlib import Path

from coding_agent.runtime.sandbox import SandboxRunner
from coding_agent.test_parser import format_pytest_failures, parse_pytest_failures
from coding_agent.tools.base import ToolResult
from coding_agent.tools.safety import is_sensitive_path, resolve_workspace_path, truncate
from coding_agent.tools.schema import ToolArg, ToolArgsSchema


ALLOWED_COMMANDS = {
    ("python", "-m", "pytest"),
    ("python", "-m", "unittest"),
    ("python", "-m", "ruff", "check"),
    ("python", "-m", "mypy"),
    ("git", "diff"),
    ("git", "status"),
}

PATH_ACCEPTING_PREFIXES = {
    ("python", "-m", "pytest"),
    ("python", "-m", "ruff", "check"),
    ("python", "-m", "mypy"),
}


@dataclass
class RunCommandTool:
    """受限命令执行工具。

    只允许 ALLOWED_COMMANDS 里的命令前缀，避免模型执行危险 shell 命令。
    """

    workspace: Path
    timeout_seconds: int = 30
    command_mode: str = "workspace"
    runner: SandboxRunner | None = None
    name: str = "run_command"
    description: str = "Run a whitelisted command. Args: {'command': string}."
    args_schema: ToolArgsSchema = ToolArgsSchema(
        args=(
            ToolArg(name="command", type="string", description="Whitelisted command to run in the workspace.", required=True),
        )
    )

    def run(self, args: dict) -> ToolResult:
        command = args.get("command")
        if not command:
            return ToolResult(False, "", "Missing required arg: command")

        try:
            # shlex 把命令字符串拆成参数列表，避免交给 shell 解释。
            parts = tuple(shlex.split(command))
        except ValueError as exc:
            return ToolResult(False, "", f"Invalid command: {exc}")

        allowed, reason = self._validate_command(parts)
        if not allowed:
            return ToolResult(False, "", reason)

        try:
            # 不使用 shell=True，减少命令注入风险。
            runner = self.runner or SandboxRunner()
            process = runner.run(parts, self.workspace, self.command_mode, self.timeout_seconds)
        except FileNotFoundError as exc:
            return ToolResult(False, "", f"Command not found: {exc.filename}")
        except TimeoutError:
            return ToolResult(False, "", f"Command timed out after {self.timeout_seconds}s")
        except Exception as exc:
            if exc.__class__.__name__ == "TimeoutExpired":
                return ToolResult(False, "", f"Command timed out after {self.timeout_seconds}s")
            return ToolResult(False, "", str(exc))

        content = summarize_command_output(process.returncode, process.stdout, process.stderr, parts)
        return ToolResult(process.returncode == 0, truncate(content), None if process.returncode == 0 else "Command failed")

    def _validate_command(self, parts: tuple[str, ...]) -> tuple[bool, str]:
        """校验命令是否在安全白名单内。"""
        matched_prefix = next((prefix for prefix in ALLOWED_COMMANDS if parts[: len(prefix)] == prefix), None)
        if matched_prefix is None:
            allowed = ", ".join(" ".join(item) for item in sorted(ALLOWED_COMMANDS))
            return False, f"Command is not allowed. Allowed prefixes: {allowed}"

        extra_args = parts[len(matched_prefix) :]
        if not extra_args:
            return True, ""
        if matched_prefix == ("python", "-m", "unittest"):
            return False, "Extra arguments are not allowed for python -m unittest"
        if matched_prefix in {("git", "diff"), ("git", "status")}:
            return False, f"Extra arguments are not allowed for {' '.join(matched_prefix)}"
        if matched_prefix in PATH_ACCEPTING_PREFIXES:
            return self._validate_path_args(extra_args)
        return False, "Unsupported command shape"

    def _validate_path_args(self, args: tuple[str, ...]) -> tuple[bool, str]:
        for arg in args:
            if arg.startswith("-"):
                return False, f"Command option is not allowed: {arg}"
            try:
                path = resolve_workspace_path(self.workspace, arg)
            except ValueError as exc:
                return False, str(exc)
            if is_sensitive_path(path):
                return False, f"Refusing to run command on sensitive path: {arg}"
        return True, ""


def summarize_command_output(exit_code: int, stdout: str, stderr: str, command_parts: tuple[str, ...] | None = None) -> str:
    """生成命令输出摘要。

    保留完整 stdout/stderr，但在顶部放一段短摘要，方便模型先看关键结果。
    """
    summary_lines = [f"exit_code={exit_code}"]
    if exit_code == 0:
        summary_lines.append("summary=Command succeeded.")
    else:
        combined = [line.strip() for line in (stderr + "\n" + stdout).splitlines() if line.strip()]
        important = combined[:8]
        summary_lines.append("summary=Command failed.")
        if important:
            summary_lines.append("important_output:")
            summary_lines.extend(f"- {line}" for line in important)
        if command_parts is not None and command_parts[:3] == ("python", "-m", "pytest"):
            summary_lines.append(format_pytest_failures(parse_pytest_failures(stderr + "\n" + stdout)))

    summary = "\n".join(summary_lines)
    return f"{summary}\n\nSTDOUT:\n{stdout}\nSTDERR:\n{stderr}"
