from __future__ import annotations

import argparse
import sys
from pathlib import Path

from coding_agent.agent import Agent
from coding_agent.audit import JsonlAuditTracer, JsonlSpanTracer
from coding_agent.config import ConfigError, load_config
from coding_agent.v2.context import ContextEngine
from coding_agent.v2.guardrails import GuardrailEngine
from coding_agent.llm import LLMClient
from coding_agent.runtime.session_store import SessionNotFoundError, SessionStore
from coding_agent.v2.tool_adapters import LocalMcpServer, McpToolAdapter
from coding_agent.tracing import CompositeTracer, ConsoleTracer, Tracer
from coding_agent.tools.factory import build_default_tools, build_review_tools
from coding_agent.v2.workflow import StagedWorkflow


def build_parser() -> argparse.ArgumentParser:
    """定义命令行参数。"""
    parser = argparse.ArgumentParser(description="A small OpenAI-powered CLI coding agent.")
    parser.add_argument("task", nargs="*", help="Task for the coding agent.")
    parser.add_argument("--workspace", default=".", help="Workspace directory. Defaults to current directory.")
    parser.add_argument("--max-steps", type=int, default=5, help="Maximum agent tool-use steps.")
    parser.add_argument("--max-errors", type=int, default=2, help="Maximum consecutive model/tool errors.")
    parser.add_argument("--yes", action="store_true", help="Apply edit tools without interactive confirmation.")
    parser.add_argument("--verbose", action="store_true", help="Print agent execution trace.")
    parser.add_argument("--trace-file", help="Write JSONL audit trace to this file.")
    parser.add_argument("--trace-format", choices=["events", "spans"], default="events", help="JSONL trace format.")
    parser.add_argument("--review", action="store_true", help="Run in read-only code review mode.")
    parser.add_argument("--session-id", help="Persist this run under the given session id.")
    parser.add_argument("--history-db", default=".coding-agent/sessions.sqlite", help="SQLite history database path.")
    parser.add_argument("--resume-session", action="store_true", help="Load previous session summary into model input.")
    parser.add_argument("--command-mode", choices=["workspace", "temp"], default="workspace", help="Run commands in the workspace or a temporary copy.")
    parser.add_argument("--workflow", choices=["legacy", "staged"], default="staged", help="Agent workflow controller.")
    parser.add_argument("--tool-adapter", choices=["direct", "mcp"], default="direct", help="Tool execution adapter.")
    return parser


def main(argv: list[str] | None = None) -> int:
    """CLI 主入口。

    返回整数退出码，方便命令行和测试判断运行是否成功。
    """
    parser = build_parser()
    args = parser.parse_args(argv)
    task = " ".join(args.task).strip()
    if not task:
        # 没有任务时不请求模型，直接展示帮助。
        parser.print_help()
        return 2

    workspace = Path(args.workspace).resolve()
    if not workspace.exists() or not workspace.is_dir():
        print(f"Workspace does not exist or is not a directory: {workspace}", file=sys.stderr)
        return 2

    try:
        config = load_config()
    except ConfigError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    session_store = None
    history_summary = None
    if args.resume_session and not args.session_id:
        print("--resume-session requires --session-id", file=sys.stderr)
        return 2
    if args.session_id:
        session_store = SessionStore(Path(args.history_db))
        if args.resume_session:
            try:
                history_summary = session_store.load_history_summary(args.session_id)
            except SessionNotFoundError as exc:
                print(str(exc), file=sys.stderr)
                return 2

    # 组装依赖：真实 OpenAI 客户端 + 工具注册表 + Agent 控制循环。
    tools = build_review_tools(workspace) if args.review else build_default_tools(workspace, args.yes, command_mode=args.command_mode)
    llm = LLMClient(
        api_key=config.api_key,
        model=config.model,
        base_url=config.base_url,
        api_mode=config.api_mode,
        tool_calling_mode=config.tool_calling_mode,
        tools=tools.function_specs(),
    )
    tracer = build_tracer(args.verbose, args.trace_file, args.trace_format)
    tool_adapter = McpToolAdapter(LocalMcpServer(tools)) if args.tool_adapter == "mcp" else None
    agent = Agent(
        llm=llm,
        tools=tools,
        max_steps=args.max_steps,
        max_errors=args.max_errors,
        tracer=tracer,
        review_mode=args.review,
        session_store=session_store,
        session_id=args.session_id,
        session_workspace=workspace,
        history_summary=history_summary,
        context_engine=ContextEngine(workspace),
        guardrails=GuardrailEngine(workspace),
        workflow=StagedWorkflow() if args.workflow == "staged" else None,
        tool_adapter=tool_adapter,
    )
    print(agent.run(task))
    return 0


def build_tracer(verbose: bool, trace_file: str | None, trace_format: str = "events") -> Tracer | None:
    tracers: list[Tracer] = []
    if verbose:
        tracers.append(ConsoleTracer())
    if trace_file:
        tracers.append(JsonlSpanTracer(Path(trace_file)) if trace_format == "spans" else JsonlAuditTracer(Path(trace_file)))
    if not tracers:
        return None
    if len(tracers) == 1:
        return tracers[0]
    return CompositeTracer(tracers)


if __name__ == "__main__":
    raise SystemExit(main())
