from __future__ import annotations

import json
from typing import Protocol

from coding_agent.v2.actions import STRUCTURED_ACTION_SCHEMA


class LLM(Protocol):
    """模型客户端的最小接口。

    Agent 只依赖这个接口，不直接依赖 OpenAI SDK。
    这样测试时可以传入假的 LLM，不需要真的请求 API。
    """

    def respond(self, instructions: str, user_input: str) -> str:
        ...


class LLMClient:
    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str | None = None,
        api_mode: str = "responses",
        tool_calling_mode: str = "json",
        tools: list[dict] | None = None,
    ) -> None:
        # 懒加载 openai 包：这样单元测试里的假模型不需要安装真实 SDK。
        try:
            from openai import OpenAI
        except ModuleNotFoundError as exc:
            raise RuntimeError("The openai package is required. Install with: python -m pip install -e .") from exc

        # base_url 为空时使用 OpenAI 官方地址；不为空时接入第三方兼容服务。
        self._client = OpenAI(api_key=api_key, base_url=base_url)
        self._model = model
        self._api_mode = api_mode
        self._tool_calling_mode = tool_calling_mode
        self._tools = tools or []

    def respond(self, instructions: str, user_input: str) -> str:
        """调用模型，并返回纯文本输出。"""
        if self._api_mode == "chat_completions":
            return self._respond_with_chat_completions(instructions, user_input)
        return self._respond_with_responses(instructions, user_input)

    def _respond_with_responses(self, instructions: str, user_input: str) -> str:
        """Responses API：适合 OpenAI 原生接口。"""
        kwargs = {
            "model": self._model,
            "instructions": instructions,
            "input": user_input,
        }
        if self._uses_native_tools():
            kwargs["tools"] = self._responses_tools()
        if self._uses_structured_outputs():
            kwargs["text"] = {"format": _responses_structured_response_format()}
        response = self._client.responses.create(**kwargs)
        tool_action = self._extract_responses_tool_action(response)
        if tool_action is not None:
            return tool_action
        return self._normalize_final_text(getattr(response, "output_text", ""))

    def _respond_with_chat_completions(self, instructions: str, user_input: str) -> str:
        """Chat Completions API：适合 DeepSeek 等第三方兼容服务。"""
        kwargs = {
            "model": self._model,
            "messages": [
                {"role": "system", "content": instructions},
                {"role": "user", "content": user_input},
            ],
        }
        if self._uses_native_tools():
            kwargs["tools"] = self._chat_tools()
        if self._uses_structured_outputs():
            kwargs["response_format"] = {
                "type": "json_schema",
                "json_schema": _chat_structured_response_format(),
            }
        response = self._client.chat.completions.create(**kwargs)
        message = response.choices[0].message
        tool_action = self._extract_chat_tool_action(message)
        if tool_action is not None:
            return tool_action
        content = message.content
        return self._normalize_final_text(content or "")

    def _uses_native_tools(self) -> bool:
        return self._tool_calling_mode == "native" and bool(self._tools)

    def _uses_structured_outputs(self) -> bool:
        return self._tool_calling_mode == "structured"

    def _responses_tools(self) -> list[dict]:
        return [
            {
                "type": "function",
                "name": tool["name"],
                "description": tool["description"],
                "parameters": tool["parameters"],
            }
            for tool in self._tools
        ]

    def _chat_tools(self) -> list[dict]:
        return [{"type": "function", "function": tool} for tool in self._tools]

    def _extract_responses_tool_action(self, response: object) -> str | None:
        output = getattr(response, "output", None) or []
        for item in output:
            item_type = _get_attr_or_key(item, "type")
            if item_type != "function_call":
                continue
            name = _get_attr_or_key(item, "name")
            arguments = _get_attr_or_key(item, "arguments") or {}
            if isinstance(name, str):
                return _tool_action_json(name, arguments)
        return None

    def _extract_chat_tool_action(self, message: object) -> str | None:
        tool_calls = getattr(message, "tool_calls", None) or []
        function = None
        if tool_calls:
            function = getattr(tool_calls[0], "function", None)
        if function is None:
            function = getattr(message, "function_call", None)
        if function is None:
            return None
        name = getattr(function, "name", None)
        arguments = getattr(function, "arguments", {}) or {}
        if not isinstance(name, str):
            return None
        return _tool_action_json(name, arguments)

    def _normalize_final_text(self, content: str) -> str:
        if self._tool_calling_mode != "native":
            return content
        stripped = content.strip()
        if stripped.startswith("{") and stripped.endswith("}"):
            return content
        return json.dumps({"final": content}, ensure_ascii=False)


def _tool_action_json(name: str, arguments: object) -> str:
    if isinstance(arguments, str):
        try:
            args = json.loads(arguments) if arguments.strip() else {}
        except json.JSONDecodeError:
            args = {}
    elif isinstance(arguments, dict):
        args = arguments
    else:
        args = {}
    if not isinstance(args, dict):
        args = {}
    return json.dumps({"tool": name, "args": args}, ensure_ascii=False)


def _get_attr_or_key(value: object, key: str) -> object | None:
    if isinstance(value, dict):
        return value.get(key)
    return getattr(value, key, None)


def _chat_structured_response_format() -> dict:
    """生成 Chat Completions 使用的结构化输出配置。"""
    return {
        "name": "coding_agent_action",
        "strict": False,
        "schema": STRUCTURED_ACTION_SCHEMA,
    }


def _responses_structured_response_format() -> dict:
    """生成 Responses API 使用的结构化输出配置。"""
    value = _chat_structured_response_format()
    value["type"] = "json_schema"
    return value
