from __future__ import annotations

import ast
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from coding_agent.code_intelligence import ProjectIntelligence, analyze_project
from coding_agent.tools.safety import is_sensitive_path


SKIP_DIRS = {".git", ".idea", ".pytest_cache", "__pycache__", ".venv", "build", "dist"}
KEY_FILES = {"README.md", "pyproject.toml", "requirements.txt", "package.json"}


@dataclass(frozen=True)
class PythonSymbols:
    path: str
    classes: list[str] = field(default_factory=list)
    functions: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class WorkspaceSummary:
    file_count: int
    directory_count: int
    file_types: dict[str, int]
    key_files: list[str]
    entrypoints: list[str]
    python_symbols: list[PythonSymbols]
    project_intelligence: ProjectIntelligence | None = None

    def to_text(self) -> str:
        lines = [
            f"files: {self.file_count}",
            f"directories: {self.directory_count}",
            "file_types:",
        ]
        for suffix, count in sorted(self.file_types.items()):
            lines.append(f"- {suffix}: {count}")

        lines.append("key_files:")
        lines.extend(f"- {path}" for path in self.key_files or ["(none)"])

        lines.append("entrypoints:")
        lines.extend(f"- {path}" for path in self.entrypoints or ["(none)"])

        lines.append("python_symbols:")
        if not self.python_symbols:
            lines.append("- (none)")
        for symbols in self.python_symbols:
            parts = []
            if symbols.classes:
                parts.append("classes=" + ", ".join(symbols.classes))
            if symbols.functions:
                parts.append("functions=" + ", ".join(symbols.functions))
            lines.append(f"- {symbols.path}: {'; '.join(parts) if parts else '(none)'}")

        if self.project_intelligence is not None:
            lines.append("project_intelligence:")
            lines.append(self.project_intelligence.to_text())
        return "\n".join(lines)


def summarize_workspace(workspace: Path, max_python_files: int = 20) -> WorkspaceSummary:
    """生成工作区的轻量摘要。"""
    workspace = workspace.resolve()
    file_count = 0
    directory_count = 0
    file_types: Counter[str] = Counter()
    key_files: list[str] = []
    entrypoints: list[str] = []
    python_symbols: list[PythonSymbols] = []

    for path in _iter_workspace_paths(workspace):
        rel = path.relative_to(workspace).as_posix()
        if path.is_dir():
            directory_count += 1
            continue

        file_count += 1
        suffix = path.suffix.lower() or "(no extension)"
        file_types[suffix] += 1

        if path.name in KEY_FILES:
            key_files.append(rel)
        if _is_entrypoint(path, rel):
            entrypoints.append(rel)
        if path.suffix == ".py" and len(python_symbols) < max_python_files:
            python_symbols.append(_parse_python_symbols(path, rel))

    return WorkspaceSummary(
        file_count=file_count,
        directory_count=directory_count,
        file_types=dict(file_types),
        key_files=sorted(key_files),
        entrypoints=sorted(entrypoints),
        python_symbols=python_symbols,
        project_intelligence=analyze_project(workspace),
    )


def _iter_workspace_paths(workspace: Path):
    for path in workspace.rglob("*"):
        if any(part in SKIP_DIRS for part in path.relative_to(workspace).parts):
            continue
        if is_sensitive_path(path):
            continue
        yield path


def _is_entrypoint(path: Path, rel: str) -> bool:
    if path.name in {"main.py", "__main__.py", "app.py"}:
        return True
    if rel == "src/coding_agent/main.py":
        return True
    return False


def _parse_python_symbols(path: Path, rel: str) -> PythonSymbols:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"))
    except (SyntaxError, UnicodeDecodeError):
        return PythonSymbols(path=rel)

    classes = [node.name for node in tree.body if isinstance(node, ast.ClassDef)]
    functions = [node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    return PythonSymbols(path=rel, classes=classes, functions=functions)
