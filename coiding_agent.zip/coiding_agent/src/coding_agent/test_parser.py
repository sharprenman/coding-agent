from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class PytestFailure:
    """单个 pytest 失败用例的结构化摘要。"""

    test_name: str
    path: str | None = None
    line: int | None = None
    assertion: str | None = None
    traceback_line: str | None = None

    def to_text(self) -> str:
        parts = [self.test_name]
        if self.path is not None:
            location = self.path if self.line is None else f"{self.path}:{self.line}"
            parts.append(f"location={location}")
        if self.assertion:
            parts.append(f"assertion={self.assertion}")
        if self.traceback_line:
            parts.append(f"traceback={self.traceback_line}")
        return " | ".join(parts)


def parse_pytest_failures(output: str) -> list[PytestFailure]:
    """从 pytest 文本输出中提取失败用例、位置和断言摘要。"""
    failures = _failures_from_summary(output)
    if not failures:
        failures = _failures_from_sections(output)
    return failures


def format_pytest_failures(failures: list[PytestFailure]) -> str:
    if not failures:
        return "pytest_failures: none parsed"
    lines = ["pytest_failures:"]
    lines.extend(f"- {failure.to_text()}" for failure in failures)
    return "\n".join(lines)


def _failures_from_summary(output: str) -> list[PytestFailure]:
    failures = []
    for line in output.splitlines():
        if not line.startswith("FAILED "):
            continue
        match = re.match(r"FAILED\s+(\S+)(?:\s+-\s+(.*))?", line)
        if not match:
            continue
        test_name = match.group(1)
        detail = (match.group(2) or "").strip() or None
        path, line_number = _location_from_test_name(test_name)
        failures.append(
            PytestFailure(
                test_name=test_name,
                path=path,
                line=line_number,
                assertion=detail,
                traceback_line=_find_traceback_line(output, path),
            )
        )
    return failures


def _failures_from_sections(output: str) -> list[PytestFailure]:
    failures = []
    current_test: str | None = None
    lines = output.splitlines()
    for index, line in enumerate(lines):
        section = re.match(r"_+\s+(.+?)\s+_+$", line)
        if section:
            current_test = section.group(1).strip()
            continue
        if current_test is None:
            continue
        location = re.match(r"([^:\s]+\.py):(\d+):\s*(.*)", line.strip())
        if not location:
            continue
        path = location.group(1)
        line_number = int(location.group(2))
        assertion = _find_assertion_near(lines, index)
        failures.append(
            PytestFailure(
                test_name=current_test,
                path=path,
                line=line_number,
                assertion=assertion,
                traceback_line=line.strip(),
            )
        )
        current_test = None
    return failures


def _location_from_test_name(test_name: str) -> tuple[str | None, int | None]:
    path = test_name.split("::", 1)[0] if "::" in test_name else None
    return path, None


def _find_traceback_line(output: str, path: str | None) -> str | None:
    if path is None:
        return None
    for line in output.splitlines():
        clean = line.strip()
        if clean.startswith(f"{path}:"):
            return clean
    return None


def _find_assertion_near(lines: list[str], start: int) -> str | None:
    begin = max(0, start - 8)
    end = min(len(lines), start + 8)
    for line in lines[begin:end]:
        clean = line.strip()
        if clean.startswith("E   "):
            return clean[4:].strip()
        if clean.startswith("assert "):
            return clean
    return None
