from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Protocol

from coding_agent.executor import Executor
from coding_agent.llm import LLM
from coding_agent.memory import AgentMemory
from coding_agent.planner import Planner, SimplePlanner
from coding_agent.prompts import build_agent_instructions
from coding_agent.runtime.session_store import SessionStore
from coding_agent.schema import FinalAction, InvalidAction, parse_action
from coding_agent.tools import ToolRegistry
from coding_agent.tracing import NullTracer, Tracer
from coding_agent.v2.actions import AskUserAction, PlanUpdateAction, ReviewFindingAction
from coding_agent.v2.guardrails import GuardrailEngine
from coding_agent.v2.tool_adapters import ToolAdapter
from coding_agent.v2.workflow import AgentPhase, StagedWorkflow


class AgentContextEngine(Protocol):
    """Agent 依赖的最小上下文引擎接口。"""

    def build(self, task: str, **kwargs):
        ...


@dataclass
class Agent:
    """最小 coding agent。

    它负责三件事：
    1. 把用户任务和工具说明发给模型。
    2. 解析模型返回的 JSON。
    3. 如果模型请求工具，就执行工具并把观察结果继续发回模型。
    """

    llm: LLM
    tools: ToolRegistry
    max_steps: int = 5
    max_errors: int = 2
    tracer: Tracer | None = None
    planner: Planner | None = None
    review_mode: bool = False
    session_store: SessionStore | None = None
    session_id: str | None = None
    session_workspace: Path | None = None
    history_summary: str | None = None
    context_engine: AgentContextEngine | None = None
    guardrails: GuardrailEngine | None = None
    workflow: StagedWorkflow | None = None
    tool_adapter: ToolAdapter | None = None
    last_memory: AgentMemory | None = field(default=None, init=False)

    def run(self, task: str) -> str:
        """运行一次任务，直到模型给出 final 或达到最大步数。"""
        tracer = self.tracer or NullTracer()
        if self.guardrails is not None:
            input_decision = self.guardrails.check_input(task)
            if not input_decision.allowed:
                return f"Blocked by guardrail: {input_decision.reason}"
        executor = Executor(self.tools, tracer, guardrails=self.guardrails, workflow=self.workflow, adapter=self.tool_adapter)
        memory = AgentMemory(user_task=task, history_summary=self.history_summary)
        self.last_memory = memory
        if self.session_store is not None and self.session_id is not None:
            self.session_store.create_or_update_session(self.session_id, self.session_workspace or Path.cwd(), task)
        planner = self.planner or SimplePlanner()
        plan = planner.plan(task)
        memory.set_plan(plan)
        if self.context_engine is not None:
            memory.set_context(
                self.context_engine.build(
                    task,
                    plan=plan,
                    history_summary=self.history_summary,
                    allowed_tools=self.tools.names(),
                )
            )
        tracer.plan(plan)
        self._append_session_event(0, "plan", {"steps": plan.steps})
        consecutive_errors = 0

        for step in range(1, self.max_steps + 1):
            # 每一轮都把可用工具列表放进 prompt，模型才知道能调用哪些工具。
            instructions = build_agent_instructions(self.tools.descriptions(), review_mode=self.review_mode)
            raw = self.llm.respond(instructions=instructions, user_input=memory.to_model_input())
            tracer.model_response(step, raw)
            self._append_session_event(step, "model_response", {"content": raw})
            action = parse_action(raw)

            # final 表示模型已经完成任务，可以把答案直接返回给用户。
            if isinstance(action, FinalAction):
                if self.guardrails is not None:
                    self.guardrails.check_output(action.final)
                tracer.final(step, action.final)
                self._append_session_event(step, "final", {"content": action.final})
                if self.session_store is not None and self.session_id is not None:
                    self.session_store.set_final(self.session_id, action.final)
                return action.final

            if isinstance(action, PlanUpdateAction):
                memory.add_observation(step, True, "Plan updated: " + "; ".join(action.steps), None)
                self._append_session_event(step, "plan_update", {"steps": action.steps})
                continue

            if isinstance(action, AskUserAction):
                final = f"Additional input required: {action.question}"
                tracer.final(step, final)
                self._append_session_event(step, "ask_user", {"question": action.question})
                if self.session_store is not None and self.session_id is not None:
                    self.session_store.set_final(self.session_id, final)
                return final

            if isinstance(action, ReviewFindingAction):
                content = f"{action.severity}: {action.file}"
                if action.line is not None:
                    content += f":{action.line}"
                content += f" - {action.message}"
                memory.add_observation(step, True, content, None)
                self._append_session_event(
                    step,
                    "review_finding",
                    {"file": action.file, "line": action.line, "severity": action.severity, "message": action.message},
                )
                continue

            # 否则模型应该返回 tool + args，Agent 负责真正执行工具。
            if isinstance(action, InvalidAction):
                consecutive_errors += 1
                memory.add_observation(step, False, "", action.error)
                self._append_session_event(step, "invalid_action", {"error": action.error, "raw": action.raw})
                if consecutive_errors >= self.max_errors:
                    final = f"Stopped after {consecutive_errors} consecutive errors: {action.error}"
                    if self.session_store is not None and self.session_id is not None:
                        self.session_store.set_final(self.session_id, final)
                    return final
                continue

            self._append_session_event(step, "tool_call", {"tool": action.tool, "args": action.args})
            if self.workflow is not None:
                self.workflow.enter(self.workflow.phase_for_tool(action.tool))
            result = executor.execute(step, action)
            if self.workflow is not None:
                self.workflow.enter(AgentPhase.REVIEW if result.ok else AgentPhase.EXPLORE)
            memory.add_observation(step, result.ok, result.content, result.error)
            self._append_session_event(
                step,
                "tool_result",
                {"ok": result.ok, "content": result.content, "error": result.error},
            )
            consecutive_errors = 0 if result.ok else consecutive_errors + 1
            if consecutive_errors >= self.max_errors:
                error = result.error or "Tool failed"
                final = f"Stopped after {consecutive_errors} consecutive errors: {error}"
                if self.session_store is not None and self.session_id is not None:
                    self.session_store.set_final(self.session_id, final)
                return final

        final = f"Stopped after {self.max_steps} steps without a final answer."
        if self.session_store is not None and self.session_id is not None:
            self.session_store.set_final(self.session_id, final)
        return final

    def _append_session_event(self, step: int, event_type: str, payload: dict) -> None:
        if self.session_store is not None and self.session_id is not None:
            self.session_store.append_event(self.session_id, step, event_type, payload)
